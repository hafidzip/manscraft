import { useEffect, useRef, useState } from 'react';
import { Engine, HOTBAR_NAMES, HOTBAR_COLORS } from './game/engine';

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<Engine | null>(null);
  const [locked, setLocked] = useState(false);
  const [slot, setSlot] = useState(0);
  const [fps, setFps] = useState(0);

  useEffect(() => {
    if (!canvasRef.current) return;
    const engine = new Engine(canvasRef.current, {
      onLock: setLocked,
      onSlot: setSlot,
      onFps: setFps,
    });
    engineRef.current = engine;
    const prevent = (e: MouseEvent) => e.preventDefault();
    document.addEventListener('contextmenu', prevent);
    return () => {
      document.removeEventListener('contextmenu', prevent);
      engine.dispose();
      engineRef.current = null;
    };
  }, []);

  return (
    <div className="fixed inset-0 overflow-hidden bg-black select-none">
      <canvas ref={canvasRef} className="block h-full w-full" />

      {/* FPS + pipeline badge */}
      <div className="pointer-events-none absolute left-3 top-3 font-mono text-xs text-amber-100/80 drop-shadow">
        <div>{fps} FPS</div>
        <div className="mt-1 text-[10px] leading-4 text-amber-100/50">
          forward → shadow (½) → SSGI ½res<br />
          → blur → SSR water → ACES
        </div>
      </div>

      {/* crosshair */}
      {locked && (
        <div className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
          <div className="relative h-5 w-5">
            <div className="absolute left-1/2 top-0 h-full w-[2px] -translate-x-1/2 bg-white/70 mix-blend-difference" />
            <div className="absolute top-1/2 left-0 w-full h-[2px] -translate-y-1/2 bg-white/70 mix-blend-difference" />
          </div>
        </div>
      )}

      {/* hotbar */}
      <div className="pointer-events-none absolute bottom-4 left-1/2 flex -translate-x-1/2 gap-1.5">
        {HOTBAR_NAMES.map((name, i) => (
          <div
            key={name}
            className={`flex h-14 w-14 flex-col items-center justify-center rounded-md border-2 backdrop-blur-sm transition-all ${
              i === slot
                ? 'border-amber-200 bg-black/50 scale-110 shadow-lg shadow-amber-900/50'
                : 'border-white/20 bg-black/35'
            }`}
          >
            <div
              className="h-7 w-7 rounded-sm border border-black/40 shadow-inner"
              style={{ backgroundColor: HOTBAR_COLORS[i] }}
            />
            <span className="mt-0.5 text-[9px] font-medium text-white/80">{i + 1} {name}</span>
          </div>
        ))}
      </div>

      {/* start overlay */}
      {!locked && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center bg-black/55">
          <div className="mx-4 max-w-md rounded-2xl border border-amber-500/25 bg-gradient-to-b from-zinc-900/90 to-zinc-950/90 p-8 text-center shadow-2xl">
            <h1 className="bg-gradient-to-b from-amber-200 via-amber-400 to-orange-600 bg-clip-text text-4xl font-black tracking-tight text-transparent">
              GOLDEN HOUR
            </h1>
            <p className="mt-1 text-sm font-medium tracking-widest text-amber-100/60">
              VOXEL WORLD · SSGI + SSR FORWARD RENDERER
            </p>
            <div className="mx-auto mt-6 grid w-fit grid-cols-2 gap-x-6 gap-y-1.5 text-left text-xs text-zinc-300">
              <span className="text-amber-200/80">Click canvas</span><span>lock mouse & play</span>
              <span className="text-amber-200/80">W A S D</span><span>move</span>
              <span className="text-amber-200/80">Space / Shift</span><span>jump / sprint</span>
              <span className="text-amber-200/80">Left click</span><span>break block</span>
              <span className="text-amber-200/80">Right click</span><span>place block</span>
              <span className="text-amber-200/80">1–7 / wheel</span><span>select block</span>
              <span className="text-amber-200/80">Esc</span><span>release mouse</span>
            </div>
            <p className="mt-6 text-[11px] leading-5 text-zinc-500">
              Optimized forward pipeline: shadow-mapped golden-hour sun, half-res
              SSGI bounce + AO, water SSR, ACES tonemap.
            </p>
            <p className="mt-4 animate-pulse text-sm font-semibold text-amber-300">Click to play</p>
          </div>
        </div>
      )}
    </div>
  );
}
