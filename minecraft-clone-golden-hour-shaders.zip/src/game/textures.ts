import * as THREE from 'three';

// ---------------------------------------------------------------------------
// Procedural 16x16 pixel-art texture atlas (4x4 tiles)
// Tile indices:
// 0 grass-top  1 grass-side  2 dirt   3 stone
// 4 sand       5 log-side    6 log-top 7 leaves
// 8 water      9 planks
// ---------------------------------------------------------------------------

const TILE = 16;
const GRID = 4;

function hash2(x: number, y: number, seed = 0): number {
  const s = Math.sin(x * 127.1 + y * 311.7 + seed * 74.7) * 43758.5453;
  return s - Math.floor(s);
}

type Painter = (px: number, py: number) => [number, number, number];

function mix(a: number[], b: number[], t: number): [number, number, number] {
  return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
}

const painters: Painter[] = [
  // 0 grass top
  (x, y) => {
    const n = hash2(x, y, 1);
    const base: [number, number, number] = [86, 152, 62];
    const dark: [number, number, number] = [64, 122, 46];
    const light: [number, number, number] = [116, 176, 78];
    if (n > 0.82) return light;
    if (n < 0.22) return dark;
    return mix(base, light, hash2(x * 3, y * 3, 2) * 0.3) as [number, number, number];
  },
  // 1 grass side
  (x, y) => {
    const grassDepth = 3 + Math.floor(hash2(x, 0, 3) * 3);
    if (15 - y < grassDepth) {
      const n = hash2(x, y, 1);
      return n > 0.5 ? [92, 158, 66] : [70, 132, 50];
    }
    const n = hash2(x, y, 4);
    if (n > 0.85) return [158, 116, 84];
    if (n < 0.18) return [104, 72, 48];
    return [134, 96, 66];
  },
  // 2 dirt
  (x, y) => {
    const n = hash2(x, y, 4);
    if (n > 0.85) return [158, 116, 84];
    if (n < 0.18) return [104, 72, 48];
    return [134, 96, 66];
  },
  // 3 stone
  (x, y) => {
    const n = hash2(x, y, 5);
    const crack = hash2(Math.floor(x / 3), Math.floor(y / 4), 6);
    if (crack > 0.9 && n > 0.5) return [96, 96, 100];
    if (n > 0.8) return [148, 148, 152];
    if (n < 0.2) return [110, 110, 116];
    return [128, 128, 133];
  },
  // 4 sand
  (x, y) => {
    const n = hash2(x, y, 7);
    if (n > 0.85) return [234, 218, 166];
    if (n < 0.18) return [200, 180, 128];
    return [220, 202, 148];
  },
  // 5 log side
  (x, y) => {
    const stripe = hash2(Math.floor(x / 2), 0, 8) * 0.5 + Math.sin(x * 1.9) * 0.3;
    const n = hash2(x, y, 9) * 0.25;
    const t = Math.max(0, Math.min(1, 0.5 + stripe * 0.5 + n - 0.2));
    return mix([76, 56, 34], [116, 88, 56], t) as [number, number, number];
  },
  // 6 log top
  (x, y) => {
    const dx = x - 7.5, dy = y - 7.5;
    const r = Math.sqrt(dx * dx + dy * dy);
    const ring = Math.sin(r * 2.4) * 0.5 + 0.5;
    if (r > 7) return [82, 62, 38];
    return mix([132, 102, 64], [166, 132, 88], ring) as [number, number, number];
  },
  // 7 leaves
  (x, y) => {
    const n = hash2(x, y, 10);
    if (n > 0.86) return [82, 130, 48];
    if (n < 0.3) return [36, 74, 28];
    return [54, 100, 36];
  },
  // 8 water
  (x, y) => {
    const n = hash2(x, y, 11);
    const wave = Math.sin((x + y * 2) * 0.8) * 0.5 + 0.5;
    return mix([24, 68, 96], [38, 96, 126], wave * 0.6 + n * 0.3) as [number, number, number];
  },
  // 9 planks
  (x, y) => {
    const plank = Math.floor(y / 4);
    const edge = y % 4 === 0 || (plank % 2 === 0 ? x === 3 : x === 11);
    const n = hash2(x, y + plank * 31, 12);
    if (edge) return [110, 82, 48];
    return mix([160, 124, 74], [184, 146, 92], n) as [number, number, number];
  },
];

export function makeAtlas(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = TILE * GRID;
  canvas.height = TILE * GRID;
  const ctx = canvas.getContext('2d')!;
  const img = ctx.createImageData(canvas.width, canvas.height);
  for (let ti = 0; ti < painters.length; ti++) {
    const tx = (ti % GRID) * TILE;
    const ty = Math.floor(ti / GRID) * TILE;
    for (let y = 0; y < TILE; y++) {
      for (let x = 0; x < TILE; x++) {
        const [r, g, b] = painters[ti](x, y);
        const idx = ((ty + y) * canvas.width + (tx + x)) * 4;
        img.data[idx] = r;
        img.data[idx + 1] = g;
        img.data[idx + 2] = b;
        img.data[idx + 3] = 255;
      }
    }
  }
  ctx.putImageData(img, 0, 0);
  const tex = new THREE.CanvasTexture(canvas);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.generateMipmaps = false;
  return tex;
}

// UV rect for a tile index (with small inset to prevent bleeding)
export function tileUV(index: number): [number, number, number, number] {
  const inset = 0.35 / (TILE * GRID);
  const u0 = (index % GRID) / GRID + inset;
  const v0 = 1 - (Math.floor(index / GRID) + 1) / GRID + inset;
  const size = 1 / GRID - inset * 2;
  return [u0, v0, size, size];
}
