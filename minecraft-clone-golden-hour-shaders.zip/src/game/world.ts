import * as THREE from 'three';
import { tileUV } from './textures';

export const CHUNK = 16;
export const WORLD_H = 48;
export const SEA = 12;

export const AIR = 0, GRASS = 1, DIRT = 2, STONE = 3, SAND = 4, WATER = 5, LOG = 6, LEAVES = 7, PLANK = 8;

const BLOCK_TILES: Record<number, number[]> = {
  [GRASS]: [1, 1, 0, 2, 1, 1],
  [DIRT]: [2, 2, 2, 2, 2, 2],
  [STONE]: [3, 3, 3, 3, 3, 3],
  [SAND]: [4, 4, 4, 4, 4, 4],
  [WATER]: [8, 8, 8, 8, 8, 8],
  [LOG]: [5, 5, 6, 6, 5, 5],
  [LEAVES]: [7, 7, 7, 7, 7, 7],
  [PLANK]: [9, 9, 9, 9, 9, 9],
};

export const isSolid = (b: number) => b !== AIR && b !== WATER;

// ------------------------------------------------------------------ noise
function hash2(x: number, z: number, seed = 0): number {
  const s = Math.sin(x * 127.1 + z * 311.7 + seed * 74.3) * 43758.5453123;
  return s - Math.floor(s);
}

function smooth(t: number) {
  return t * t * (3 - 2 * t);
}

function valueNoise(x: number, z: number, seed: number): number {
  const xi = Math.floor(x), zi = Math.floor(z);
  const xf = x - xi, zf = z - zi;
  const a = hash2(xi, zi, seed), b = hash2(xi + 1, zi, seed);
  const c = hash2(xi, zi + 1, seed), d = hash2(xi + 1, zi + 1, seed);
  const u = smooth(xf), v = smooth(zf);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}

function fbm(x: number, z: number, seed: number, oct: number): number {
  let amp = 0.5, freq = 1, sum = 0, norm = 0;
  for (let i = 0; i < oct; i++) {
    sum += valueNoise(x * freq, z * freq, seed + i * 13) * amp;
    norm += amp;
    amp *= 0.5;
    freq *= 2.05;
  }
  return sum / norm;
}

// ------------------------------------------------------------------ world
export class World {
  edits = new Map<string, number>();
  private heightCache = new Map<number, number>();
  private treeCache = new Map<number, boolean>();

  private colKey(x: number, z: number) {
    return ((x + 50000) << 16) | ((z + 50000) & 0xffff);
  }

  height(x: number, z: number): number {
    const key = this.colKey(x, z);
    let h = this.heightCache.get(key);
    if (h !== undefined) return h;
    // 2 octaves base + 2 hills — enough shape, far cheaper than before
    const base = fbm(x * 0.014, z * 0.014, 3, 2);
    const hills = fbm(x * 0.04, z * 0.04, 17, 2);
    h = (6 + base * 22 + hills * 10) | 0;
    if (h < 2) h = 2;
    else if (h > WORLD_H - 10) h = WORLD_H - 10;
    this.heightCache.set(key, h);
    return h;
  }

  treeAt(x: number, z: number): boolean {
    const key = this.colKey(x, z);
    let t = this.treeCache.get(key);
    if (t !== undefined) return t;
    const h = this.height(x, z);
    t = h > SEA + 1 && h < WORLD_H - 12 && hash2(x * 3 + 7, z * 5 + 11, 91) < 0.012;
    this.treeCache.set(key, t);
    return t;
  }

  getBlock(x: number, y: number, z: number): number {
    if (y < 0 || y >= WORLD_H) return AIR;
    const e = this.edits.get(x + ',' + y + ',' + z);
    if (e !== undefined) return e;
    const h = this.height(x, z);
    if (y <= h) {
      if (y === h) return h <= SEA + 1 ? SAND : GRASS;
      if (y >= h - 3) return h <= SEA + 1 ? SAND : DIRT;
      return STONE;
    }
    if (y <= SEA) return WATER;
    if (this.treeAt(x, z) && y > h && y <= h + 4) return LOG;
    // leaves only near canopy height band
    if (y > h + 2 && y <= h + 7) {
      for (let tx = x - 2; tx <= x + 2; tx++) {
        for (let tz = z - 2; tz <= z + 2; tz++) {
          if (!this.treeAt(tx, tz)) continue;
          const th = this.height(tx, tz);
          const top = th + 4;
          if (y < top - 1 || y > top + 2) continue;
          const r = y <= top ? 2 : 1;
          const dx = Math.abs(x - tx), dz = Math.abs(z - tz);
          if (dx > r || dz > r) continue;
          if (dx === 0 && dz === 0 && y <= top) continue;
          if (dx === r && dz === r && hash2(x * 7 + y, z * 13 + y, 55) < 0.6) continue;
          if (y === top + 2 && dx + dz > 1) continue;
          return LEAVES;
        }
      }
    }
    return AIR;
  }

  setBlock(x: number, y: number, z: number, b: number) {
    this.edits.set(x + ',' + y + ',' + z, b);
  }
}

// ------------------------------------------------------------------ meshing
const FACES = [
  { dir: [1, 0, 0] as const, corners: [[1, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1]] as const, a1: 1, a2: 2 },
  { dir: [-1, 0, 0] as const, corners: [[0, 0, 0], [0, 0, 1], [0, 1, 1], [0, 1, 0]] as const, a1: 1, a2: 2 },
  { dir: [0, 1, 0] as const, corners: [[0, 1, 1], [1, 1, 1], [1, 1, 0], [0, 1, 0]] as const, a1: 0, a2: 2 },
  { dir: [0, -1, 0] as const, corners: [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]] as const, a1: 0, a2: 2 },
  { dir: [0, 0, 1] as const, corners: [[0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]] as const, a1: 0, a2: 1 },
  { dir: [0, 0, -1] as const, corners: [[1, 0, 0], [0, 0, 0], [0, 1, 0], [1, 1, 0]] as const, a1: 0, a2: 1 },
];
const CORNER_UV = [[0, 0], [1, 0], [1, 1], [0, 1]] as const;

// Pre-sized mesh buffers (reused across builds to cut GC)
const MAX_VERTS = 45000;
const posBuf = new Float32Array(MAX_VERTS * 3);
const nrmBuf = new Float32Array(MAX_VERTS * 3);
const uvBuf = new Float32Array(MAX_VERTS * 2);
const aoBuf = new Float32Array(MAX_VERTS);
const idxBuf = new Uint32Array(MAX_VERTS * 2);

const MAX_WATER = 8000;
const wPos = new Float32Array(MAX_WATER * 3);
const wNrm = new Float32Array(MAX_WATER * 3);
const wUv = new Float32Array(MAX_WATER * 2);
const wAo = new Float32Array(MAX_WATER);
const wIdx = new Uint32Array(MAX_WATER * 2);

function packGeometry(
  pos: Float32Array, nrm: Float32Array, uv: Float32Array, ao: Float32Array,
  idx: Uint32Array, vCount: number, iCount: number
): THREE.BufferGeometry | null {
  if (iCount === 0) return null;
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos.slice(0, vCount * 3), 3));
  g.setAttribute('normal', new THREE.BufferAttribute(nrm.slice(0, vCount * 3), 3));
  g.setAttribute('uv', new THREE.BufferAttribute(uv.slice(0, vCount * 2), 2));
  g.setAttribute('ao', new THREE.BufferAttribute(ao.slice(0, vCount), 1));
  g.setIndex(new THREE.BufferAttribute(idx.slice(0, iCount), 1));
  g.computeBoundingSphere();
  return g;
}

export function buildChunk(world: World, cx: number, cz: number): {
  solid: THREE.BufferGeometry | null;
  water: THREE.BufferGeometry | null;
} {
  const x0 = cx * CHUNK, z0 = cz * CHUNK;
  const P = CHUNK + 2;
  const cache = new Uint8Array(P * WORLD_H * P);

  // Precompute column heights + trees for padded region (huge win vs per-voxel noise)
  const colH = new Int16Array(P * P);
  const colTree = new Uint8Array(P * P);
  let minH = WORLD_H, maxH = 0;
  for (let x = 0; x < P; x++) {
    for (let z = 0; z < P; z++) {
      const wx = x0 + x - 1, wz = z0 + z - 1;
      const h = world.height(wx, wz);
      colH[x * P + z] = h;
      colTree[x * P + z] = world.treeAt(wx, wz) ? 1 : 0;
      if (h < minH) minH = h;
      if (h > maxH) maxH = h;
    }
  }

  // Fill block cache using column data (avoids repeated getBlock/tree scans)
  const yMax = Math.min(WORLD_H - 1, Math.max(SEA, maxH + 7));
  for (let x = 0; x < P; x++) {
    for (let z = 0; z < P; z++) {
      const wx = x0 + x - 1, wz = z0 + z - 1;
      const h = colH[x * P + z];
      const base = (x * P + z) * WORLD_H;
      for (let y = 0; y <= h; y++) {
        if (y === h) cache[base + y] = h <= SEA + 1 ? SAND : GRASS;
        else if (y >= h - 3) cache[base + y] = h <= SEA + 1 ? SAND : DIRT;
        else cache[base + y] = STONE;
      }
      for (let y = h + 1; y <= SEA; y++) cache[base + y] = WATER;
      if (colTree[x * P + z]) {
        for (let y = h + 1; y <= h + 4 && y < WORLD_H; y++) cache[base + y] = LOG;
      }
      // leaves from nearby trees in pad
      for (let y = h + 3; y <= h + 7 && y < WORLD_H; y++) {
        if (cache[base + y] !== AIR && cache[base + y] !== 0) continue;
        let leaf = false;
        for (let tx = Math.max(0, x - 2); tx <= Math.min(P - 1, x + 2) && !leaf; tx++) {
          for (let tz = Math.max(0, z - 2); tz <= Math.min(P - 1, z + 2); tz++) {
            if (!colTree[tx * P + tz]) continue;
            const th = colH[tx * P + tz];
            const top = th + 4;
            if (y < top - 1 || y > top + 2) continue;
            const r = y <= top ? 2 : 1;
            const dx = Math.abs(x - tx), dz = Math.abs(z - tz);
            if (dx > r || dz > r) continue;
            if (dx === 0 && dz === 0 && y <= top) continue;
            if (dx === r && dz === r && hash2((wx) * 7 + y, (wz) * 13 + y, 55) < 0.6) continue;
            if (y === top + 2 && dx + dz > 1) continue;
            leaf = true;
            break;
          }
        }
        if (leaf && cache[base + y] === AIR) cache[base + y] = LEAVES;
      }
      // apply player edits for this column
      for (let y = 0; y < WORLD_H; y++) {
        const e = world.edits.get(wx + ',' + y + ',' + wz);
        if (e !== undefined) cache[base + y] = e;
      }
    }
  }

  const get = (lx: number, ly: number, lz: number): number => {
    if (ly < 0 || ly >= WORLD_H) return AIR;
    const px = lx + 1, pz = lz + 1;
    if (px < 0 || px >= P || pz < 0 || pz >= P) return AIR;
    return cache[(px * P + pz) * WORLD_H + ly];
  };

  let sv = 0, si = 0;
  let wv = 0, wi = 0;

  const meshYMin = Math.max(0, minH - 4);
  const meshYMax = yMax;

  for (let lx = 0; lx < CHUNK; lx++) {
    for (let lz = 0; lz < CHUNK; lz++) {
      for (let y = meshYMin; y <= meshYMax; y++) {
        const b = get(lx, y, lz);
        if (b === AIR) continue;
        const tiles = BLOCK_TILES[b];
        if (!tiles) continue;
        const isWater = b === WATER;

        for (let f = 0; f < 6; f++) {
          const face = FACES[f];
          const nb = get(lx + face.dir[0], y + face.dir[1], lz + face.dir[2]);
          if (isWater) {
            if (nb !== AIR) continue;
          } else {
            if (isSolid(nb)) continue;
          }

          const [u0, v0, us, vs] = tileUV(tiles[f]);
          const a1 = face.a1, a2 = face.a2;
          const aoVals = [1, 1, 1, 1];

          if (isWater) {
            if (wv + 4 >= MAX_WATER) continue;
            const baseV = wv;
            for (let c = 0; c < 4; c++) {
              const co = face.corners[c];
              const i3 = wv * 3, i2 = wv * 2;
              wPos[i3] = x0 + lx + co[0];
              wPos[i3 + 1] = y + co[1];
              wPos[i3 + 2] = z0 + lz + co[2];
              wNrm[i3] = face.dir[0];
              wNrm[i3 + 1] = face.dir[1];
              wNrm[i3 + 2] = face.dir[2];
              wUv[i2] = u0 + CORNER_UV[c][0] * us;
              wUv[i2 + 1] = v0 + CORNER_UV[c][1] * vs;
              wAo[wv] = 1;
              wv++;
            }
            wIdx[wi++] = baseV;
            wIdx[wi++] = baseV + 1;
            wIdx[wi++] = baseV + 2;
            wIdx[wi++] = baseV;
            wIdx[wi++] = baseV + 2;
            wIdx[wi++] = baseV + 3;
          } else {
            if (sv + 4 >= MAX_VERTS) continue;
            const baseV = sv;
            for (let c = 0; c < 4; c++) {
              const co = face.corners[c];
              const t1 = co[a1] * 2 - 1, t2 = co[a2] * 2 - 1;
              const bx = lx + face.dir[0], by = y + face.dir[1], bz = lz + face.dir[2];
              const o = [bx, by, bz];
              const p1 = [o[0], o[1], o[2]]; p1[a1] += t1;
              const p2 = [o[0], o[1], o[2]]; p2[a2] += t2;
              const pc = [o[0], o[1], o[2]]; pc[a1] += t1; pc[a2] += t2;
              const s1 = isSolid(get(p1[0], p1[1], p1[2])) ? 1 : 0;
              const s2 = isSolid(get(p2[0], p2[1], p2[2])) ? 1 : 0;
              const sc = isSolid(get(pc[0], pc[1], pc[2])) ? 1 : 0;
              const occ = s1 && s2 ? 3 : s1 + s2 + sc;
              const ao = 1 - occ * 0.22;
              aoVals[c] = ao;

              const i3 = sv * 3, i2 = sv * 2;
              posBuf[i3] = x0 + lx + co[0];
              posBuf[i3 + 1] = y + co[1];
              posBuf[i3 + 2] = z0 + lz + co[2];
              nrmBuf[i3] = face.dir[0];
              nrmBuf[i3 + 1] = face.dir[1];
              nrmBuf[i3 + 2] = face.dir[2];
              uvBuf[i2] = u0 + CORNER_UV[c][0] * us;
              uvBuf[i2 + 1] = v0 + CORNER_UV[c][1] * vs;
              aoBuf[sv] = ao;
              sv++;
            }
            if (aoVals[0] + aoVals[2] >= aoVals[1] + aoVals[3]) {
              idxBuf[si++] = baseV;
              idxBuf[si++] = baseV + 1;
              idxBuf[si++] = baseV + 2;
              idxBuf[si++] = baseV;
              idxBuf[si++] = baseV + 2;
              idxBuf[si++] = baseV + 3;
            } else {
              idxBuf[si++] = baseV + 1;
              idxBuf[si++] = baseV + 2;
              idxBuf[si++] = baseV + 3;
              idxBuf[si++] = baseV + 1;
              idxBuf[si++] = baseV + 3;
              idxBuf[si++] = baseV;
            }
          }
        }
      }
    }
  }

  return {
    solid: packGeometry(posBuf, nrmBuf, uvBuf, aoBuf, idxBuf, sv, si),
    water: packGeometry(wPos, wNrm, wUv, wAo, wIdx, wv, wi),
  };
}
