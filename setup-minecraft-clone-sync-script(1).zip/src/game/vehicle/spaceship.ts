
import * as THREE from 'three';
import { buildInstanced } from '../vfx/laserTool';
import type { Particles } from '../vfx/particles';
import type { World } from '../world/world';
import type { TerrainGenerator } from '../world/generator';
import type { SoundEngine } from '../audio/sound';
import { HULL_PARTS, GLOW_PARTS } from './hullParts';
import { minImageF, wrapBlock } from '../core/constants';

export interface FlightInput {
  forward: boolean;
  back: boolean;
  left: boolean;
  right: boolean;
  up: boolean;
  down: boolean;
}

const UP_AXIS = new THREE.Vector3(0, 1, 0);

const MAX_SPEED = 28;
const MAX_VSPEED = 13;
const ACCEL = 26;
const VACCEL = 18;
const HX = 3.2, HY = 1.15, HZ = 3.5;

function makeFlameTexture(): THREE.CanvasTexture {
  const S = 64;
  const c = document.createElement('canvas');
  c.width = S;
  c.height = S;
  const ctx = c.getContext('2d')!;
  const g = ctx.createRadialGradient(S / 2, S / 2, 1, S / 2, S / 2, S / 2);
  g.addColorStop(0, 'rgba(255,255,255,1)');
  g.addColorStop(0.3, 'rgba(140,200,255,0.75)');
  g.addColorStop(0.7, 'rgba(60,120,255,0.22)');
  g.addColorStop(1, 'rgba(40,80,255,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, S, S);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

export class Spaceship {
  readonly group = new THREE.Group();
  readonly pos = new THREE.Vector3();
  readonly vel = new THREE.Vector3();
  yaw = 0;
  private bank = 0;
  private pitchVis = 0;
  private flyPitch = 0;
  private bobT = Math.random() * 10;
  private baseY = 0;
  private exhaustCd = 0;
  private load = 0;

  private glowMat = new THREE.MeshBasicMaterial();
  private flame: THREE.Sprite;
  private light: THREE.PointLight;
  private nozzle = new THREE.Object3D();

  private tmpA = new THREE.Vector3();
  private tmpB = new THREE.Vector3();

  private renderRef = new THREE.Vector3();
  private hasRenderRef = false;
  private tmpImg = new THREE.Vector3();
  readonly lastWrap = new THREE.Vector3();

  constructor(
    scene: THREE.Scene,
    private world: World,
    private particles: Particles
  ) {
    this.group.add(buildInstanced(HULL_PARTS, new THREE.MeshLambertMaterial()));
    this.group.add(buildInstanced(GLOW_PARTS, this.glowMat));
    this.nozzle.position.set(0, 0.9, 3.6);
    this.group.add(this.nozzle);

    this.flame = new THREE.Sprite(new THREE.SpriteMaterial({
      map: makeFlameTexture(), transparent: true, opacity: 0, depthWrite: false,
      blending: THREE.AdditiveBlending,
    }));
    this.flame.position.set(0, 0.9, 3.8);
    this.group.add(this.flame);

    this.light = new THREE.PointLight(0x7fb2ff, 0, 14, 2);
    this.light.position.set(0, 1.2, 3.2);
    this.group.add(this.light);

    this.group.traverse((o) => (o.frustumCulled = false));
    scene.add(this.group);
  }

  placeNear(gen: TerrainGenerator, cx: number, cz: number): void {
    let bx = cx + 7;
    let bz = cz + 3;
    let best = Infinity;
    for (let r = 5; r <= 26; r += 4) {
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * Math.PI * 2;
        const x = cx + Math.cos(a) * r;
        const z = cz + Math.sin(a) * r;
        const { minH, maxH } = this.footprintHeights(gen, x, z);
        if (minH <= 31) continue;
        const cost = (maxH - minH) * 4 + Math.abs(r - 10);
        if (cost < best) {
          best = cost;
          bx = x;
          bz = z;
          this.pos.set(bx, maxH + 1.35, bz);
          if (maxH - minH === 0) r = 99;
        }
      }
    }
    if (!isFinite(best)) {
      const x = cx + 7;
      const z = cz + 3;
      this.pos.set(x, this.footprintHeights(gen, x, z).maxH + 1.35, z);
    }
    this.baseY = this.pos.y;
    this.yaw = Math.random() * Math.PI * 2;
    this.vel.set(0, 0, 0);
    this.pitchVis = 0;
    this.flyPitch = 0;
    this.bank = 0;
    this.load = 0;
    this.recenter();
    this.sync();
  }

  enterAtmosphere(gen: TerrainGenerator, cx: number, cz: number, yaw: number): void {
    const h = this.footprintHeights(gen, cx, cz).maxH;
    this.pos.set(wrapBlock(cx), Math.min(155, Math.max(118, h + 86)), wrapBlock(cz));
    this.baseY = this.pos.y;
    this.yaw = yaw;
    this.vel.set(0, 0, 0);
    this.pitchVis = -0.08;
    this.flyPitch = -0.08;
    this.bank = 0;
    this.sync();
  }

  recenter(): void {
    const nx = wrapBlock(this.pos.x);
    const nz = wrapBlock(this.pos.z);
    this.lastWrap.set(nx - this.pos.x, 0, nz - this.pos.z);
    this.pos.x = nx;
    this.pos.z = nz;
  }

  imageNear(ref: THREE.Vector3, out: THREE.Vector3 = this.tmpImg): THREE.Vector3 {
    return out.set(
      ref.x + minImageF(this.pos.x - ref.x),
      this.pos.y,
      ref.z + minImageF(this.pos.z - ref.z),
    );
  }

  syncRender(ref: THREE.Vector3): void {
    this.renderRef.copy(ref);
    this.hasRenderRef = true;
    this.applyRenderImage();
  }

  private applyRenderImage(): void {
    if (!this.hasRenderRef) { this.group.position.copy(this.pos); return; }
    this.group.position.copy(this.imageNear(this.renderRef, this.tmpImg));
  }

  distanceTo(p: THREE.Vector3): number {
    const dx = minImageF(this.pos.x - p.x);
    const dy = this.pos.y - p.y;
    const dz = minImageF(this.pos.z - p.z);
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
  }

  seatWorld(out: THREE.Vector3, lookPitch: number): THREE.Vector3 {
    out.set(0, 1.78, -0.8).applyAxisAngle(UP_AXIS, this.yaw);
    out.add(this.pos);
    out.y += Math.sin(-lookPitch) * 0.1;
    if (this.hasRenderRef) {
      out.x = this.renderRef.x + minImageF(out.x - this.renderRef.x);
      out.z = this.renderRef.z + minImageF(out.z - this.renderRef.z);
    }
    return out;
  }

  private footprintHeights(gen: TerrainGenerator, cx: number, cz: number): { minH: number; maxH: number } {
    let minH = Infinity;
    let maxH = -Infinity;
    for (let x = Math.floor(cx - HX); x <= Math.ceil(cx + HX); x += 2) {
      for (let z = Math.floor(cz - HZ); z <= Math.ceil(cz + HZ); z += 2) {
        const h = gen.heightAt(x, z);
        if (h < minH) minH = h;
        if (h > maxH) maxH = h;
      }
    }
    return { minH, maxH };
  }

  private footprintGroundY(): number {
    let gy = 0;
    for (let x = Math.floor(this.pos.x - HX); x <= Math.ceil(this.pos.x + HX); x += 2) {
      for (let z = Math.floor(this.pos.z - HZ); z <= Math.ceil(this.pos.z + HZ); z += 2) {
        gy = Math.max(gy, this.world.highestY(x, z));
      }
    }
    return gy;
  }

  ensureClearance(margin = 0.25): void {
    const safeY = this.footprintGroundY() + 1.1 + margin;
    if (this.pos.y < safeY) this.pos.y = safeY;
    this.baseY = Math.max(this.baseY, this.pos.y);
    this.sync();
  }

  private sync(): void {
    this.applyRenderImage();
    this.group.rotation.set(this.pitchVis, this.yaw, this.bank, 'YXZ');
    this.flame.scale.setScalar(0.6 + this.load * 2.6 + Math.sin(this.bobT * 31) * 0.12 * this.load);
  }

  settleHere(): void {
    this.recenter();
    const gy = this.footprintGroundY();
    this.pos.y = Math.max(gy + 1.35, Math.min(this.pos.y, gy + HY + 1.4));
    this.baseY = this.pos.y;
    this.vel.set(0, 0, 0);
    this.pitchVis = 0;
    this.bank = 0;
    this.sync();
    this.group.rotation.set(0, this.yaw, 0);
  }

  updateParked(dt: number): void {
    this.bobT += dt;
    this.vel.set(0, 0, 0);
    this.pos.y = this.baseY + Math.sin(this.bobT * 1.05) * 0.09;
    this.load += (0.12 - this.load) * Math.min(1, dt * 2);
    const pulse = 0.5 + 0.12 * Math.sin(this.bobT * 3);
    this.glowMat.color.setRGB(0.4 * pulse + 0.2, 0.55 * pulse + 0.2, 0.7 * pulse + 0.25);
    this.light.intensity = 1.5 + Math.sin(this.bobT * 6) * 0.4;
    this.flame.material.opacity = 0.16 + 0.06 * Math.sin(this.bobT * 9);
    this.flame.scale.setScalar(0.5 + Math.sin(this.bobT * 7) * 0.05);
    this.applyRenderImage();
    this.group.rotation.set(0, this.yaw, 0);
  }

  updatePilot(
    dt: number,
    orbitYaw: number,
    orbitPitch: number,
    inp: FlightInput,
    sound: SoundEngine
  ): void {
    this.bobT += dt;

    let dyaw = orbitYaw - this.yaw;
    dyaw = ((dyaw + Math.PI) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2) - Math.PI;
    this.yaw += dyaw * Math.min(1, 10 * dt);
    this.flyPitch += (orbitPitch - this.flyPitch) * Math.min(1, 11 * dt);
    const targetPitchVis = this.flyPitch * 0.35;
    this.pitchVis += (targetPitchVis - this.pitchVis) * Math.min(1, 9 * dt);

    const cy = this.yaw;
    const cp = this.flyPitch;
    const fy = Math.sin(cp);
    const fx = -Math.sin(cy) * Math.cos(cp);
    const fz = -Math.cos(cy) * Math.cos(cp);
    const rx = Math.cos(cy);
    const rz = -Math.sin(cy);

    let ax = 0, ay = 0, az = 0;
    if (inp.forward) { ax += fx; ay += fy * 0.55; az += fz; }
    if (inp.back) { ax -= fx * 0.6; az -= fz * 0.6; }
    if (inp.right) { ax += rx * 0.55; az += rz * 0.55; }
    if (inp.left) { ax -= rx * 0.55; az -= rz * 0.55; }
    if (inp.up) ay += 1;
    if (inp.down) ay -= 1;

    const hLen = Math.hypot(ax, az);
    if (hLen > 1) { ax /= hLen; az /= hLen; }

    this.vel.x += (ax * MAX_SPEED - this.vel.x) * Math.min(1, (ax === 0 ? 2.2 : ACCEL / MAX_SPEED * 4) * dt);
    this.vel.z += (az * MAX_SPEED - this.vel.z) * Math.min(1, (az === 0 ? 2.2 : ACCEL / MAX_SPEED * 4) * dt);
    this.vel.y += (ay * MAX_VSPEED - this.vel.y) * Math.min(1, (ay === 0 ? 3.2 : VACCEL / MAX_VSPEED * 5) * dt);

    const lat = this.vel.x * rx + this.vel.z * rz;
    const targetBank = THREE.MathUtils.clamp(-lat * 0.02, -0.45, 0.45);
    this.bank += (targetBank - this.bank) * Math.min(1, 5 * dt);

    this.moveAxis(0, this.vel.x * dt);
    this.moveAxis(1, this.vel.y * dt);
    this.moveAxis(2, this.vel.z * dt);
    if (this.pos.y < 2) { this.pos.y = 2; this.vel.y = Math.max(0, this.vel.y); }
    if (this.pos.y > 420) { this.pos.y = 420; this.vel.y = Math.min(0, this.vel.y); }

    this.recenter();

    const spd = this.speed();
    const loadTarget = Math.min(1, spd / MAX_SPEED + (ay !== 0 ? 0.15 : 0));
    this.load += (loadTarget - this.load) * Math.min(1, 4 * dt);
    sound.setShip(this.load, spd);

    this.glowMat.color.setRGB(0.35 + 0.65 * this.load, 0.62 + 0.3 * this.load, 0.85);
    this.light.intensity = 2 + this.load * 10 + Math.sin(this.bobT * 37) * this.load * 2;

    this.flame.material.opacity = 0.25 + this.load * 0.7 + Math.sin(this.bobT * 41) * 0.08;
    const fScale = 0.5 + this.load * 2.4 + Math.sin(this.bobT * 33) * 0.15 * this.load;
    this.flame.scale.setScalar(Math.max(0.01, fScale));

    this.exhaustCd -= dt;
    if (this.load > 0.15 && this.exhaustCd <= 0) {
      this.exhaustCd = 0.06;
      this.nozzle.getWorldPosition(this.tmpA);
      this.tmpB.set(Math.sin(this.yaw), 0, Math.cos(this.yaw));
      this.particles.burst(
        this.tmpA.x + this.tmpB.x * 0.4, this.tmpA.y, this.tmpA.z + this.tmpB.z * 0.4,
        [0x9fd4ff, 0x5e94e8, 0xd8ecff, 0x3f6fd0],
        2 + Math.floor(this.load * 3), 1.4
      );
    }

    this.sync();
  }

  private collides(): boolean {
    const x0 = Math.floor(this.pos.x - HX);
    const x1 = Math.floor(this.pos.x + HX);
    const y0 = Math.floor(this.pos.y - 0.1);
    const y1 = Math.floor(this.pos.y + HY);
    const z0 = Math.floor(this.pos.z - HZ);
    const z1 = Math.floor(this.pos.z + HZ);
    for (let x = x0; x <= x1; x++)
      for (let y = y0; y <= y1; y++)
        for (let z = z0; z <= z1; z++)
          if (this.world.isSolid(x, y, z)) return true;
    return false;
  }

  private moveAxis(axis: 0 | 1 | 2, d: number): void {
    if (d === 0) return;
    const EPS = 0.02;
    if (axis === 0) {
      this.pos.x += d;
      if (this.collides()) {
        this.pos.x = d > 0
          ? Math.floor(this.pos.x + HX) - HX - EPS
          : Math.floor(this.pos.x - HX) + 1 + HX + EPS;
        this.vel.x = 0;
      }
      return;
    }
    if (axis === 2) {
      this.pos.z += d;
      if (this.collides()) {
        this.pos.z = d > 0
          ? Math.floor(this.pos.z + HZ) - HZ - EPS
          : Math.floor(this.pos.z - HZ) + 1 + HZ + EPS;
        this.vel.z = 0;
      }
      return;
    }
    this.pos.y += d;
    if (!this.collides()) return;
    this.pos.y = d > 0
      ? Math.floor(this.pos.y + HY) - HY - EPS
      : Math.floor(this.pos.y - 0.1) + 1 + 0.1 + EPS;
    this.vel.y = 0;
    if (d < 0) {
      this.baseY = this.pos.y;
    }
  }

  speed(): number {
    return this.vel.length();
  }

  get bankAngle(): number {
    return this.bank;
  }
}
