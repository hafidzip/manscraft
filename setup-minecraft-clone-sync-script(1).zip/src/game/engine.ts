
import * as THREE from 'three';
import * as C from './core/constants';
import { createTextures, tileUV, animateConveyorTiles, type TextureSet } from './core/textures';
import { B, DEFS, isWaterId, applyThemeToBlockColors, conveyorDir, isConveyor, isInserter, isLaserMiner, isOreBlock, canLaserBreak, isLaserProtected } from './world/blocks';
import { World, type ChunkMaterials } from './world/world';
import { InserterManager, type InserterAutomation } from './fps/Inserter';
import { LaserMinerManager } from './fps/LaserMiner';
import { TurretManager } from './fps/Turret';
import { FlowField } from './fps/FlowField';
import { ChangeBus } from './world/changeBus';
import { MachineRegistry, MK_GHOST } from './world/machineRegistry';
import { MachineScheduler } from './fps/machineScheduler';
import { setActivePlanetTheme, planetSeedToWorldSeed, TerrainGenerator } from './world/generator';
import type { PlanetTheme } from './space/theme';
import { hub, themeToJson } from './persist/planetStore';
import { universeSim } from './factory/universeSim';
import type { PlanetFactorySim } from './factory/factorySim';
import type { WorldDeltaStore } from './persist/worldDelta';
import type { ItemLedger } from './factory/itemLedger';
import { FluidSim } from './world/fluid';
import { WATER_TIME } from './world/mesher';
import { Player, type InputState } from './player/player';
import { raycastVoxel, type RayHit } from './player/raycast';
import { Particles } from './vfx/particles';
import { Sky } from './vfx/sky';
import { LaserTool } from './vfx/laserTool';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { DepthFogPass } from './vfx/depthFog';
import { LumenLitePass } from './vfx/lumenLite';
import { VolumetricLightPass } from './vfx/volumetric';
import { OutputStage } from './vfx/output';
import { FOG_UNIFORMS } from './vfx/heightFog';
import { SoundEngine } from './audio/sound';
import { Spaceship } from './vehicle/spaceship';
import { WeaponSystem, type GameBridge } from './fps/WeaponSystem';
import { Enemy, ENEMY_PRESETS } from './fps/Enemy';
import { EnemyManager } from './fps/EnemyManager';
import { Effects } from './fps/effects';
import { SHOP_ITEMS, COIN_REWARDS, STARTING_COINS, TRADE_DISTANCE, generateMerchantStock, getBlockSellPrice, getFoodSellPrice, type MerchantStock } from './fps/shop';
import { session, saveCoins } from './session';
import { AudioSynth } from './fps/audio';
import { HeldBlockTool } from './fps/HeldBlockTool';
import { WEAPONS, WEAPON_ORDER, buildBody } from './fps/models';
import { Inventory, BLOCK_NAMES, FOODS, type SlotItem } from './fps/Inventory';
import { matchCraft, craftableCount, RECIPES, recipeIngredients } from './crafting/recipes';
import { TorchLights } from './world/torchLights';
import {
  newFurnace, tickFurnace, furnaceIdle, isFuel, smeltResult, SMELT_TIME,
  drainFurnaceOutput, newFurnaceTickResult, type FurnaceState,
} from './crafting/smelting';
import {
  MachineKind, feedMachine, machineKey, parseMachineKey, spillCrafting, spillFurnace,
  setCraftingBlueprint, harvestOutcome, newCraftingTable, craftingTableIdle,
  type CraftingTableState, type MachineItemSink,
} from './factory/machineProcessing';
import { ItemDropManager } from './fps/ItemDrop';
import { buildExtrudedItem, paintDrumstick, pixelTexture } from './fps/textures';
import type { BodyRig } from './fps/models';
import type { Target, HotbarItem, HudStats, EngineEvents } from './engine/types';
import {
  SPACE_ALTITUDE, LOAD_LABELS, UNDERWATER_FOG, NIGHT_MIST, LASER_NAME, DEATH_DURATION,
  CELESTIAL_SHADOW_SIZE, CELESTIAL_SHADOW_HALF_EXTENT, GRASS_SHADOW_RADIUS,
  TO_FPS, FROM_FPS, B_COAL, B_STICK, GUN_ICON_COLORS,
} from './engine/constants';

export type { HotbarItem, HudStats, EngineEvents } from './engine/types';

export class GameEngine {
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera: THREE.PerspectiveCamera;
  private clock = new THREE.Clock();

  private theme: PlanetTheme | null = null;

  private textures!: TextureSet;
  private world!: World;
  private fluid!: FluidSim;
  private player!: Player;
  private sky!: Sky;
  private particles!: Particles;
  private laser!: LaserTool;
  private ship!: Spaceship;
  private sound = new SoundEngine();

  private fpsAudio = new AudioSynth();
  private weapons!: WeaponSystem;
  private enemies!: EnemyManager;
  private fx!: Effects;
  private heldBlock!: HeldBlockTool;
  private torchLights!: TorchLights;
  private toolMode: 'weapon' | 'laser' | 'barehand' | 'block' | 'food' = 'weapon';
  public inventory!: Inventory;
  private inserters!: InserterManager;
  private laserMiners!: LaserMinerManager;
  private turrets!: TurretManager;
  private changeBus!: ChangeBus;
  private machineRegistry!: MachineRegistry;
  private machines!: MachineScheduler;
  private flow = new FlowField();
  private lastFieldX = NaN;
  private lastFieldY = NaN;
  private lastFieldZ = NaN;
  private enemiesEnabled = true;
  private triggerDown = false;
  private prevLeft = false;
  private placeCd = 0;
  private throwCd = 0;
  private dropPos = new THREE.Vector3();
  private dropVel = new THREE.Vector3();
  private dropLift = new THREE.Vector3(0, 1.4, 0);

  private mainRT: THREE.WebGLRenderTarget | null = null;
  private lightingRT: THREE.WebGLRenderTarget | null = null;
  private fogRT: THREE.WebGLRenderTarget | null = null;
  private volumetricRT: THREE.WebGLRenderTarget | null = null;
  private giRT: THREE.WebGLRenderTarget | null = null;
  private blurRT: THREE.WebGLRenderTarget | null = null;
  private lumenLite: LumenLitePass | null = null;
  private depthFogPass: DepthFogPass | null = null;
  private bloom: UnrealBloomPass | null = null;
  private volumetricLight: VolumetricLightPass | null = null;
  private outputStage: OutputStage | null = null;
  private flashlight: THREE.SpotLight | null = null;
  private flashlightTarget = new THREE.Object3D();
  private lastShadowX = 1e9;
  private lastShadowZ = 1e9;
  private shadowCooldown = 0;
  private grassShadowT = 0;
  private inventoryOpen = false;
  private craftingOpen = false;
  private furnaces = new Map<string, FurnaceState>();
  private craftingTables = new Map<string, CraftingTableState>();
  private openFurnaceKey: string | null = null;
  private openCraftingKey: string | null = null;
  private readonly furnaceTickOut = newFurnaceTickResult();
  private sim: PlanetFactorySim | null = null;
  private persistDeltas: WorldDeltaStore | null = null;
  private persistLedger: ItemLedger | null = null;
  private worldSeed = 0;
  private themeSea = 30;
  private hitSeq = 0;
  private damageSeq = 0;
  private dmgAngle = 0;
  private dmgFollowT = 0;
  private lastDamageFrom = new THREE.Vector3();
  private hasDamageFrom = false;
  private demolition = 0;
  private blocksMined = 0;
  private mineCharge = 0;
  private switchAt = 0;
  private itemDrops!: ItemDropManager;

  private readonly machineSink: MachineItemSink = {
    emitAbove: (x, y, z, itemId, count = 1) => {
      const pos = new THREE.Vector3(x + 0.5, y + 1.15, z + 0.5);
      const vel = new THREE.Vector3(0, 0.2, 0);
      for (let i = 0; i < count; i++) this.itemDrops.spawn(itemId, pos, vel);
    },
  };

  private readonly inserterAutomation: InserterAutomation = {
    isMachine: (x, y, z) => this.machineKindAt(x, y, z) !== MachineKind.None,
    emitAbove: (x, y, z, itemId, count = 1) =>
      this.machineSink.emitAbove(x, y, z, itemId, count),
    tryInsert: (x, y, z, itemId) => {
      const kind = this.machineKindAt(x, y, z);
      if (kind === MachineKind.None) return false;
      const state = kind === MachineKind.Furnace
        ? this.furnaceStateAt(x, y, z)
        : this.craftingStateAt(x, y, z);
      const accepted = feedMachine(kind, state, x, y, z, itemId, this.machineSink);
      if (accepted) this.events.onStats(this.buildStats());
      return accepted;
    },
  };
  private heldFood!: THREE.Group;
  private droppedGun: { mesh: THREE.Object3D; vel: THREE.Vector3; spin: THREE.Vector3; settled: boolean } | null = null;
  private targets: Target[] = [];
  private raycaster = new THREE.Raycaster();
  private body!: BodyRig;
  private bodyGroup!: THREE.Group;
  private targetsHit = 0;
  private eating = false;
  private eatT = 0;
  private biteAcc = 0;
  private hp = 100;
  private maxHp = 100;
  private invulnT = 0;
  private dead = false;
  private deadTimer = 0;
  private kills = 0;
  private coins = 0;
  private coinSeq = 0;
  private lastCoinGain = 0;
  private nearMerchant = false;
  private nearMerchantEnemy: Enemy | null = null;
  private shopEnemy: Enemy | null = null;
  private shopStock: MerchantStock[] = [];
  private shopSellOpen = false;
  private time = 0;
  private spaceExited = false;

  private piloting = false;
  private flyCam = new THREE.Vector3();
  private tmpSeat = new THREE.Vector3();
  private tmpCam = new THREE.Vector3();
  private tmpShipImg = new THREE.Vector3();

  private aimPoint = new THREE.Vector3();
  private aimDir = new THREE.Vector3();

  private input: InputState = { forward: false, back: false, left: false, right: false, jump: false, sprint: false, crouch: false };
  private mouse = { left: false, right: false };
  private locked = false;
  private everLocked = false;
  private menuYaw = 0;

  private sel = 0;
  private target: RayHit | null = null;
  private breakT = 0;
  private digSoundT = 0;

  private highlight!: THREE.LineSegments;
  private crack!: THREE.Mesh;
  private crackMats: THREE.MeshBasicMaterial[] = [];
  private blockGeomCache = new Map<number, THREE.BufferGeometry>();

  private spawn = new THREE.Vector3();
  private bob = 0;
  private walkAcc = 0;
  private fov = 75;
  private fps = 60;
  private statT = 0;
  private wasOnGround = false;
  private prevVelY = 0;
  private wasInWater = false;
  private disposed = false;
  private fogScratch = new THREE.Color();
  private snapCanvas: HTMLCanvasElement | null = null;
  private snapT = 0;
  private cachedBiomeName = '';
  private biomeCheckT = 0;

  private simMsEma = 0;
  private postQ: 0 | 1 | 2 = 0;
  private postQAt = 0;
  private dtFluid = 0;
  private dtParticles = 0;
  private dtSky = 0;
  private dtBloom = 0;

  constructor(
    private canvas: HTMLCanvasElement,
    private events: EngineEvents,
    theme?: PlanetTheme | null,
    persistentInventory?: Inventory,
    private worldKey = 'home',
  ) {
    this.theme = theme ?? null;
    this.inventory = persistentInventory ?? new Inventory();
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFShadowMap;
    this.renderer.shadowMap.autoUpdate = false;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.0;

    this.camera = new THREE.PerspectiveCamera(75, 1, 0.08, 900);
    this.camera.rotation.order = 'YXZ';
    this.resize();
    window.addEventListener('resize', this.resize);
  }


  get planetTheme(): PlanetTheme | null { return this.theme; }

  async init(theme?: PlanetTheme | null): Promise<void> {
    if (theme !== undefined) this.theme = theme;
    setActivePlanetTheme(this.theme);
    this.textures = createTextures(this.theme);
    applyThemeToBlockColors(this.theme);

    const mats: ChunkMaterials & {
      opaque: THREE.MeshLambertMaterial;
      cutout: THREE.MeshLambertMaterial;
      foliage: THREE.MeshLambertMaterial;
      water: THREE.MeshLambertMaterial;
    } = {
      opaque: new THREE.MeshLambertMaterial({ map: this.textures.atlas, vertexColors: true }),
      cutout: new THREE.MeshLambertMaterial({
        map: this.textures.atlas, vertexColors: true, alphaTest: 0.4, side: THREE.DoubleSide,
      }),
      foliage: new THREE.MeshLambertMaterial({
        map: this.textures.atlas, vertexColors: true, alphaTest: 0.4, side: THREE.DoubleSide,
      }),
      water: new THREE.MeshLambertMaterial({
        map: this.textures.water, vertexColors: true, transparent: false, opacity: 1.0,
        side: THREE.DoubleSide,
      }),
    };
    mats.opaque.shadowSide = THREE.DoubleSide;
    mats.cutout.shadowSide = THREE.DoubleSide;
    mats.foliage.shadowSide = THREE.DoubleSide;
    mats.water.onBeforeCompile = (shader) => {
      shader.uniforms.uTime = WATER_TIME;
      shader.vertexShader = shader.vertexShader
        .replace(
          '#include <common>',
          '#include <common>\nattribute vec2 aFlow;\nvarying vec2 vFlow;\nvarying vec3 vWpos;'
        )
        .replace(
          '#include <uv_vertex>',
          '#include <uv_vertex>\nvFlow = aFlow;\nvWpos = (modelMatrix * vec4(position, 1.0)).xyz;'
        );
      shader.fragmentShader = shader.fragmentShader
        .replace(
          '#include <common>',
          '#include <common>\nuniform float uTime;\nvarying vec2 vFlow;\nvarying vec3 vWpos;'
        )
        .replace(
          '#include <map_fragment>',
          `vec2 flowUv = vMapUv + vFlow * uTime;
           vec2 shim = vec2(
             sin(vWpos.z * 1.9 + uTime * 0.7) + sin(vWpos.x * 1.1 - uTime * 0.5),
             cos(vWpos.x * 1.7 + uTime * 0.6) + cos(vWpos.z * 1.3 - uTime * 0.8)
           ) * 0.02;
           vec4 sampledDiffuseColor = texture2D( map, flowUv + shim );
           diffuseColor *= sampledDiffuseColor;`
        );
    };
    mats.cutout.onBeforeCompile = (shader) => {
      shader.vertexShader = shader.vertexShader
        .replace(
          '#include <common>',
          `#include <common>
           attribute vec4 aSway;
           varying float vTorchUnlit;
           varying float vIsGrass;`
        )
        .replace(
          '#include <beginnormal_vertex>',
          `#include <beginnormal_vertex>
           // ALL cutout foliage (grass blades, leaves, flowers) is lit with a
           // pure world-up normal, exactly like the grass_top terrain face.
           // normalMatrix then produces the correct view-space up vector, so
           // Lambert can never go black on sun-opposed or back-facing quads.
           // Face-to-face shading variety is already baked into vertex colours
           // by the mesher, and torches bypass lighting entirely in the
           // fragment stage, so nothing is lost by unifying the normal here.
           objectNormal = vec3(0.0, 1.0, 0.0);`
        )
        .replace(
          '#include <begin_vertex>',
          `#include <begin_vertex>
            // aSway.y = -1 -> torch (unlit). Grass geometry is now static.
           vTorchUnlit = step(aSway.y, -0.5);
           // Grass blades: normal.z > 10 (encoded as ang+100 by mesher)
           float gBlade = step(10.0, normal.z);
            vIsGrass = gBlade;`
        );
      shader.fragmentShader = shader.fragmentShader
        .replace(
          '#include <common>',
          `#include <common>
           varying float vTorchUnlit;
           varying float vIsGrass;`
        )
        .replace(
          '#include <normal_fragment_begin>',
          `float faceDirection = gl_FrontFacing ? 1.0 : -1.0;
           // vNormal is the view-space world-up for EVERY cutout vertex (the
           // vertex stage overrides objectNormal to (0,1,0)). Use it as-is:
           // NO faceDirection flip — flipping by gl_FrontFacing made lighting
           // depend on which side of the double-sided quad the camera saw,
           // which blackened backlit grass blades and tree leaves whenever
           // the player looked toward/away from the sun.
           vec3 normal = normalize(vNormal);
           vec3 nonPerturbedNormal = normal;`
        )
        .replace(
          '#include <opaque_fragment>',
          `if (vTorchUnlit > 0.5) {
             // pure atlas colour — no Lambert, no shadows, no point-light wash
             outgoingLight = diffuseColor.rgb;
           } else {
             #include <opaque_fragment>
             // Foliage wrap-translucency: guarantees grass is never fully
             // black even in cast shadows, which is the golden-hour look
             // (backlit blades scatter warm sun through their surface).
             if (vIsGrass > 0.5) {
               outgoingLight = max(outgoingLight, diffuseColor.rgb * 0.22);
             }
           }`
        );
    };

    mats.foliage.onBeforeCompile = (shader) => {
      shader.vertexShader = shader.vertexShader.replace(
        '#include <beginnormal_vertex>',
        `#include <beginnormal_vertex>
         // Leaves are lit with a pure world-up normal, exactly like terrain
         // and the grass shader — face-to-face variety is baked into vertex
         // colours by the mesher, so nothing is lost.
         objectNormal = vec3(0.0, 1.0, 0.0);`
      );
    };

    mats.cutoutDepth = new THREE.MeshDepthMaterial({
      depthPacking: THREE.RGBADepthPacking,
      map: this.textures.atlas,
      alphaTest: 0.4,
      side: THREE.DoubleSide,
    });

    mats.foliageDepth = new THREE.MeshDepthMaterial({
      depthPacking: THREE.RGBADepthPacking,
      map: this.textures.atlas,
      alphaTest: 0.4,
      side: THREE.DoubleSide,
    });

    const seed = this.theme
      ? planetSeedToWorldSeed(this.theme.seed)
      : (hub.stableSeed(this.worldKey) ?? ((Math.random() * 0x7fffffff) | 0));
    this.worldSeed = seed;
    this.themeSea = this.theme?.seaLevel ?? C.SEA_LEVEL;

    await hub.ready;
    const installed = hub.install(this.worldKey, seed, this.themeSea);
    const claimed = universeSim.claim({
      planetKey: this.worldKey,
      seed,
      makeGenerator: () => new TerrainGenerator(seed, this.theme),
      deltas: installed.deltas,
      ledger: installed.ledger,
      save: installed.save,
    });
    this.sim = claimed.sim;
    this.persistDeltas = claimed.deltas;
    this.persistLedger = claimed.ledger;
    this.furnaces = claimed.sim.furnaces;
    this.craftingTables = claimed.sim.craftingTables;

    this.world = new World(seed, mats, claimed.deltas);
    claimed.sim.attachToLive(this.world);
    this.scene.add(this.world.group);

    this.fluid = new FluidSim(this.world);
    this.world.onChanged = (x, y, z, oldId, newId) => {
      this.flow.markColumnDirty(x, z);
      if (isWaterId(oldId) || isWaterId(newId)) {
        this.fluid.pokeAround(x, y, z);
        return;
      }
      const offsets = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];
      for (const [ox, oy, oz] of offsets) {
        if (isWaterId(this.world.getBlockRaw(x + ox, y + oy, z + oz))) {
          this.fluid.pokeAround(x, y, z);
          return;
        }
      }
    };

    this.changeBus = new ChangeBus();
    this.changeBus.attach(this.world);
    this.machineRegistry = new MachineRegistry({ indexedKinds: MK_GHOST, trustGenerator: true });
    this.machineRegistry.attach(this.changeBus);
    this.machineRegistry.bootstrap(this.world);
    this.machineRegistry.retain = (k) => this.sim?.retain(k) ?? false;
    this.changeBus.add({
      onBlock: (x, y, z, oldId, newId) => {
        this.persistDeltas?.recordBlock(x, y, z, newId);
        this.sim?.onBlock(x, y, z, oldId, newId);
      },
    });

    if (this.sky) this.sky.applyTheme(this.theme?.skyHex ?? null);
    else this.sky = new Sky(this.scene, this.theme?.skyHex ?? null);

    const key = this.sky.sun;
    key.castShadow = true;
    key.shadow.mapSize.set(CELESTIAL_SHADOW_SIZE, CELESTIAL_SHADOW_SIZE);
    key.shadow.camera.left = -CELESTIAL_SHADOW_HALF_EXTENT;
    key.shadow.camera.right = CELESTIAL_SHADOW_HALF_EXTENT;
    key.shadow.camera.top = CELESTIAL_SHADOW_HALF_EXTENT;
    key.shadow.camera.bottom = -CELESTIAL_SHADOW_HALF_EXTENT;
    key.shadow.camera.near = 0.5;
    key.shadow.camera.far = 180;
    key.shadow.bias = -0.0004;
    key.shadow.normalBias = 0.16;
    key.shadow.radius = 1.0;
    key.shadow.camera.updateProjectionMatrix();

    const size = this.renderer.getDrawingBufferSize(new THREE.Vector2());

    this.mainRT = new THREE.WebGLRenderTarget(size.x, size.y, {
      type: THREE.HalfFloatType,
    });
    this.mainRT.depthTexture = new THREE.DepthTexture(size.x, size.y);
    this.mainRT.depthTexture.type = THREE.UnsignedIntType;

    this.lightingRT = new THREE.WebGLRenderTarget(size.x, size.y, {
      type: THREE.HalfFloatType,
    });
    this.fogRT = new THREE.WebGLRenderTarget(size.x, size.y, {
      type: THREE.HalfFloatType,
    });
    this.volumetricRT = new THREE.WebGLRenderTarget(size.x, size.y, {
      type: THREE.HalfFloatType,
    });

    this.depthFogPass = new DepthFogPass(this.camera);
    this.depthFogPass.material.uniforms.tDepth.value = this.mainRT.depthTexture;

    const halfW = Math.max(1, Math.floor(size.x / 2));
    const halfH = Math.max(1, Math.floor(size.y / 2));
    this.giRT = new THREE.WebGLRenderTarget(halfW, halfH, { type: THREE.HalfFloatType });
    this.blurRT = new THREE.WebGLRenderTarget(halfW, halfH, { type: THREE.HalfFloatType });

    this.lumenLite = new LumenLitePass(this.camera, size.x, size.y);

    this.bloom = new UnrealBloomPass(new THREE.Vector2(size.x, size.y), 0.3, 0.55, 0.82);

    this.volumetricLight = new VolumetricLightPass(this.scene, this.camera, size.x, size.y);

    this.outputStage = new OutputStage();

    this.flashlight = new THREE.SpotLight(
      0xfff0d8, 0, 58, THREE.MathUtils.degToRad(42), 0.62, 1.5,
    );
    this.flashlight.position.set(0.12, -0.16, 0.55);
    this.flashlightTarget.position.set(0, -1.2, -30);
    this.camera.add(this.flashlight);
    this.camera.add(this.flashlightTarget);
    this.flashlight.target = this.flashlightTarget;

    this.particles = new Particles(this.scene);
    this.laser = new LaserTool(this.scene, this.camera);

    this.highlight = new THREE.LineSegments(
      new THREE.EdgesGeometry(new THREE.BoxGeometry(1.002, 1.002, 1.002)),
      new THREE.LineBasicMaterial({ color: 0x0a0a0a, transparent: true, opacity: 0.75 })
    );
    this.highlight.visible = false;
    this.scene.add(this.highlight);

    this.crackMats = this.textures.cracks.map(
      (t) => new THREE.MeshBasicMaterial({ map: t, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2 })
    );
    this.crack = new THREE.Mesh(new THREE.BoxGeometry(1.004, 1.004, 1.004), this.crackMats[0]);
    this.crack.visible = false;
    this.crack.renderOrder = 10;
    this.scene.add(this.crack);

    this.player = new Player(this.world);
    const [sx, sz] = this.world.gen.findSpawn();
    const spawnH = this.world.gen.heightAt(sx, sz);
    this.spawn.set(sx + 0.5, spawnH + 1.01, sz + 0.5);
    this.player.setSpawn(this.spawn.x, this.spawn.y, this.spawn.z);
    this.player.yaw = Math.PI / 4;
    this.menuYaw = this.player.yaw;
    this.world.syncChunkOffsets(this.spawn.x, this.spawn.z);
    this.world.spawn.copy(this.spawn);

    this.ship = new Spaceship(this.scene, this.world, this.particles);
    this.ship.placeNear(this.world.gen, sx, sz);
    const startInShip = this.theme !== null;
    if (startInShip) {
      this.ship.enterAtmosphere(this.world.gen, this.spawn.x, this.spawn.z, this.player.yaw);
      this.player.setSpawn(this.ship.pos.x, this.ship.pos.y - 0.2, this.ship.pos.z);
      this.player.yaw = this.ship.yaw;
      this.player.pitch = -0.16;
      this.menuYaw = this.player.yaw;
    }

    let dataProgress = 0;
    while (dataProgress < 1) {
      dataProgress = this.world.prepareAllData(24);
      this.events.onProgress(dataProgress * 0.48, 'Cooking terrain data');
      if (dataProgress < 1) await this.nextFrame();
      if (this.disposed) return;
    }

    const preloadRadius = C.EVICT_DISTANCE;
    const total = World.cellsInRadius(preloadRadius);
    let loaded = 0;
    let labelIdx = -1;
    while (true) {
      loaded += this.world.update(this.player.pos.x, this.player.pos.z, 28, preloadRadius);
      if (!this.world.pendingWork && loaded >= total) break;
      const p = Math.min(0.99, loaded / total);
      const idx = Math.min(LOAD_LABELS.length - 1, Math.floor(p * LOAD_LABELS.length));
      if (idx !== labelIdx) {
        labelIdx = idx;
        this.events.onProgress(0.48 + p * 0.32, LOAD_LABELS[idx]);
      } else this.events.onProgress(0.48 + p * 0.32, LOAD_LABELS[labelIdx]);
      await this.nextFrame();
      if (this.disposed) return;
    }
    this.events.onProgress(0.8, 'World geometry ready');

    this.fx = new Effects(this.scene, this.world, this.player.pos, (pos) => this.handleExplosion(pos));
    this.fx.prewarm(Object.values(DEFS).flatMap((def) => def.colors));
    const bridge: GameBridge = {
      fireShot: (m, d, def, anchor) => this.fireShot(m, d, def.id, anchor),
      launchRocket: (m, d, anchor) => this.launchRocket(m, d, anchor),
      casing: (p, r, big) => this.fx.casing(p, r, big, this.player.vel),
    };
    this.weapons = new WeaponSystem(this.camera, this.player, this.fpsAudio, bridge, () => { });
    this.enemies = new EnemyManager(this.player, {
      world: this.world,
      effects: this.fx,
      audio: this.fpsAudio,
      camera: this.camera,
      onPlayerHit: (dmg, from) => this.damagePlayer(dmg, from),
      onEnemyKilled: (e) => { this.kills++; this.rewardCoins(e); },
      flowField: this.flow,
    });
    this.enemies.addScene(this.scene);

    for (const cfg of Object.values(ENEMY_PRESETS)) {
      pixelTexture(cfg.skin, 14, 16, cfg.seed);
      pixelTexture(cfg.shirt, 16, 16, cfg.seed + 1);
      pixelTexture(cfg.pants, 14, 16, cfg.seed + 2);
    }

    if (!Number.isFinite(session.coins)) {
      session.coins = STARTING_COINS;
      saveCoins(session.coins);
    }
    this.coins = session.coins;
    {
      const sp = this.player.pos;
      this.enemies.spawnWanderingMerchant(sp.x + 7, sp.z + 5, sp.y);
    }
    this.heldBlock = new HeldBlockTool(this.scene, this.camera, new THREE.MeshLambertMaterial({ map: this.textures.atlas, alphaTest: 0.4, side: THREE.DoubleSide }));
    this.heldBlock.setGeometry(this.blockGeometry(B.GRASS));

    this.torchLights = new TorchLights(this.scene);

    this.itemDrops = new ItemDropManager(this.scene, this.world, this.inventory, this.fpsAudio, () => {
      this.syncHotbarMode();
    }, { bus: this.changeBus, instanced: true, ledger: this.persistLedger ?? undefined });
    this.inserters = new InserterManager(this.scene, this.world, this.itemDrops, this.fpsAudio);
    this.inserters.setAutomation(this.inserterAutomation);
    this.laserMiners = new LaserMinerManager(this.scene, this.world, {
      mineable: (id) => this.laserMinerCanMine(id),
      mine: (x, y, z, dropPos) => this.laserMinerMine(x, y, z, dropPos),
    });
    this.turrets = new TurretManager(this.scene, this.world, {
      targets: () => this.enemies.enemies,
      damage: (t, amount, point) => {
        const e = t as Enemy;
        e.takeDamage(amount, point, false);
        this.enemies.alertAlliesOf(e);
      },
      muzzle: (pos) => this.fx.muzzleFlash(pos, 0.42),
      tracer: (from, to) => this.fx.tracer(from, to),
      impact: (point, normal, block) => this.fx.impact(point, normal, block),
      shot: (dist) => this.fpsAudio.shot({
        freq: 1850, dur: 0.06,
        gain: 0.22 * THREE.MathUtils.clamp(1 - dist / 90, 0.15, 1), sub: 240,
      }),
      raycast: (origin, dir, maxDist) => this.world.raycast(origin, dir, maxDist),
    });
    this.machines = new MachineScheduler(this.machineRegistry, [
      this.inserters, this.laserMiners, this.turrets,
    ]);
    this.itemDrops.prewarm(new Set(Object.values(TO_FPS)));

    for (const id of new Set(Object.values(FROM_FPS))) {
      if (DEFS[id]) this.blockGeometry(id);
    }

    this.heldFood = buildExtrudedItem(paintDrumstick, 0.017, 0.034);
    this.heldFood.position.set(0.38, -0.32, -0.52);
    this.heldFood.rotation.set(0.35, -0.55, 0.25);
    this.heldFood.scale.setScalar(1.15);
    this.heldFood.visible = false;
    this.camera.add(this.heldFood);

    this.body = buildBody();
    this.bodyGroup = this.body.group;
    this.bodyGroup.traverse((child) => {
      if (child instanceof THREE.Mesh) {
        child.castShadow = true;
        child.receiveShadow = false;
      }
      child.layers.set(2);
    });
    this.scene.add(this.bodyGroup);

    this.events.onProgress(0.86, 'Warming up equipment');
    await this.nextFrame();
    if (this.disposed) return;

    const cutoutWarmGeo = new THREE.PlaneGeometry(0.01, 0.01);
    const warmCount = cutoutWarmGeo.getAttribute('position').count;
    cutoutWarmGeo.setAttribute('color', new THREE.Float32BufferAttribute(new Array(warmCount * 3).fill(1), 3));
    cutoutWarmGeo.setAttribute('aSway', new THREE.Float32BufferAttribute(new Array(warmCount * 4).fill(0), 4));
    const cutoutWarmMesh = new THREE.Mesh(cutoutWarmGeo, mats.cutout);
    cutoutWarmMesh.frustumCulled = false;
    this.scene.add(cutoutWarmMesh);

    const foliageWarmGeo = new THREE.PlaneGeometry(0.01, 0.01);
    const foliageWarmCount = foliageWarmGeo.getAttribute('position').count;
    foliageWarmGeo.setAttribute('color', new THREE.Float32BufferAttribute(new Array(foliageWarmCount * 3).fill(1), 3));
    const foliageWarmMesh = new THREE.Mesh(foliageWarmGeo, mats.foliage);
    foliageWarmMesh.frustumCulled = false;
    this.scene.add(foliageWarmMesh);

    this.heldBlock.showTorch();
    this.heldBlock.group.visible = true;
    this.heldFood.visible = true;
    const laserWarmTarget = this.camera.position.clone().add(new THREE.Vector3(0, 0, -3));
    this.laser.update(0, { visible: true, firing: true, target: laserWarmTarget, charge: 1, speed: 0 });
    try {
      await this.weapons.warmup(this.renderer, this.scene);
    } finally {
      this.scene.remove(cutoutWarmMesh);
      cutoutWarmGeo.dispose();
      this.scene.remove(foliageWarmMesh);
      foliageWarmGeo.dispose();
      this.heldBlock.group.visible = false;
      this.heldFood.visible = false;
      this.laser.update(0, { visible: false, firing: false, target: null, charge: 0, speed: 0 });
      this.heldBlock.setGeometry(this.blockGeometry(B.GRASS));
    }
    if (this.disposed) return;

    this.events.onProgress(0.94, 'Compiling lighting pipeline');
    await this.warmupRenderPipeline();
    if (this.disposed) return;
    this.events.onProgress(1, 'All systems ready');

    this.addListeners();

    const items: HotbarItem[] = [];
    for (let i = 0; i < 5; i++) {
      const wid = WEAPON_ORDER[i];
      items.push({ id: wid, name: WEAPONS[wid].name, icon: this.makeGunIcon(i) });
    }
    items.push({ id: 'laser', name: LASER_NAME, icon: this.makeGunIcon(5) });
    this.events.onReady(items, seed);
    this.selectSlot(2, true);
    this.events.onSelect(this.sel);
    if (startInShip) this.boardShip();

    this.clock.start();
    this.renderer.setAnimationLoop(this.tick);
  }

  private nextFrame(): Promise<void> {
    return new Promise((r) => requestAnimationFrame(() => r()));
  }

  private async warmupRenderPipeline(): Promise<void> {
    const restoreWeapons = this.weapons?.beginWarmupAll?.() ?? (() => { });

    const effectColors = Object.values(DEFS).flatMap((def) => def.colors);
    this.fx?.beginWarmup?.(effectColors);

    try {
      const textures = new Set<THREE.Texture>();
      this.scene.traverse((object) => {
        const mesh = object as THREE.Mesh;
        if (!mesh.isMesh && !(object as THREE.Sprite).isSprite && !(object as THREE.Points).isPoints) return;
        const raw = (mesh as THREE.Mesh).material as THREE.Material | THREE.Material[] | undefined;
        const materials = raw ? (Array.isArray(raw) ? raw : [raw]) : [];
        for (const material of materials) {
          for (const value of Object.values(material)) {
            if (value instanceof THREE.Texture) textures.add(value);
          }
        }
      });
      for (const texture of textures) this.renderer.initTexture(texture);
      await this.renderer.compileAsync(this.scene, this.camera);
      if (this.disposed || !this.mainRT) return;

      this.sky.update(0, this.camera.position);

      for (let pass = 0; pass < 2; pass++) {
        this.renderer.shadowMap.needsUpdate = true;
        this.renderer.setRenderTarget(this.mainRT);
        this.renderer.render(this.scene, this.camera);

        this.lumenLite!.configure(
          this.sky.skyColor,
          this.sky.sunColor,
          this.sky.sunDirection,
          this.sky.dayFactor,
          this.world.gen.sea,
        );
        this.lumenLite!.renderPipeline(this.renderer, this.mainRT, this.lightingRT!, this.giRT!, this.blurRT!);
        this.depthFogPass!.render(this.renderer, this.fogRT!, this.lightingRT!, this.mainRT.depthTexture!);
        this.bloom!.render(this.renderer, this.fogRT!, this.fogRT!, 1 / 60, false);
        this.volumetricLight!.lightWorldPosition.copy(this.sky.sunWorldPos);
        this.volumetricLight!.intensity = 0.01;
        this.volumetricLight!.render(this.renderer, this.volumetricRT!, this.fogRT!);
        this.outputStage!.render(this.renderer, this.volumetricRT!.texture);
        this.renderer.setRenderTarget(null);

        if (pass === 0) {
          await this.nextFrame();
          if (this.disposed || !this.mainRT) return;
        }
      }
    } finally {
      restoreWeapons();
      this.fx?.endWarmup?.();
    }

    this.renderer.shadowMap.needsUpdate = true;
    await this.nextFrame();
  }

  private captureSnapshot(dt: number): void {
    this.snapT -= dt;
    if (this.snapT > 0) return;
    this.snapT = this.fps < 40 ? 0.5 : 0.25;
    const src = this.canvas;
    if (!src.width || !src.height) return;
    if (!this.snapCanvas) this.snapCanvas = document.createElement('canvas');
    const scale = Math.min(1, 1150 / src.width);
    const w = Math.max(2, Math.round(src.width * scale));
    const h = Math.max(2, Math.round(src.height * scale));
    if (this.snapCanvas.width !== w || this.snapCanvas.height !== h) {
      this.snapCanvas.width = w;
      this.snapCanvas.height = h;
    }
    this.snapCanvas.getContext('2d')?.drawImage(src, 0, 0, w, h);
  }

  getSnapshot(): HTMLCanvasElement | null {
    return this.snapCanvas;
  }


  private blockGeometry(id: number): THREE.BufferGeometry {
    const cached = this.blockGeomCache.get(id);
    if (cached) return cached;

    const d = DEFS[id];
    const g = new THREE.BoxGeometry(0.19, 0.19, 0.19);
    const uv = g.attributes.uv as THREE.BufferAttribute;
    const faceTiles = [d.side, d.side, d.top, d.bottom, d.side, d.side];
    const corners: [number, number][] = [[0, 1], [1, 1], [0, 0], [1, 0]];
    for (let f = 0; f < 6; f++) {
      const [u0, v0, u1, v1] = tileUV(faceTiles[f]);
      for (let i = 0; i < 4; i++) {
        const [cu, cv] = corners[i];
        uv.setXY(f * 4 + i, u0 + (u1 - u0) * cu, v0 + (v1 - v0) * cv);
      }
    }
    uv.needsUpdate = true;
    this.blockGeomCache.set(id, g);
    return g;
  }

  private makeGunIcon(i: number): string {
    const size = 44;
    const c = document.createElement('canvas');
    c.width = size;
    c.height = size;
    const ctx = c.getContext('2d')!;
    ctx.imageSmoothingEnabled = false;
    const dark = '#22242a';
    const accent = GUN_ICON_COLORS[i];
    ctx.fillStyle = dark;
    ctx.fillRect(10, 18, 24, 9);
    ctx.fillRect(22, 10, 14, 6);
    ctx.fillRect(13, 27, 8, 11);
    ctx.fillStyle = accent;
    ctx.fillRect(10, 20, 24, 3);
    if (i === 5) {
      ctx.fillRect(34, 10, 4, 6);
    } else {
      ctx.fillRect(26, 10, 4, 6);
    }
    return c.toDataURL();
  }

  private dropBlock(id: number, pos: THREE.Vector3): void {
    const fpsId = TO_FPS[id];
    if (fpsId === undefined) return;
    this.itemDrops.spawn(fpsId, pos);
    this.blocksMined++;
  }

  private laserMinerCanMine(id: number): boolean {
    if (id === B.AIR || id < 0) return false;
    if (isWaterId(id)) return false;
    if (isConveyor(id) || isInserter(id) || isLaserMiner(id) || id === B.TURRET) return false;
    if (isLaserProtected(id)) return false;
    if (isOreBlock(id)) return TO_FPS[id] !== undefined;
    const d = DEFS[id];
    if (!d || !isFinite(d.hardness)) return false;
    if (d.cross === true) return true;
    if (!d.solid) return false;
    return TO_FPS[id] !== undefined;
  }

  private laserMinerMine(x: number, y: number, z: number, dropPos: THREE.Vector3): void {
    const id = this.world.getBlockRaw(x, y, z);
    if (id < 0 || !this.laserMinerCanMine(id)) return;
    const d = DEFS[id];
    const outcome = harvestOutcome(id, TO_FPS);
    if (!outcome) {
      if (!this.world.destroyBlockAt(x, y, z)) return;
      this.finalizeBlockRemoval(x, y, z, id, true);
      this.particles.burst(x + 0.5, y + 0.5, z + 0.5, d.colors, 20, 3.2);
      this.sound.playBreak(d.sound);
      this.blocksMined++;
      return;
    }
    if (outcome.destroy) {
      if (!this.world.destroyBlockAt(x, y, z)) return;
      this.finalizeBlockRemoval(x, y, z, id, true);
    }
    this.particles.burst(x + 0.5, y + 0.5, z + 0.5, d.colors, 20, 3.2);

    const from = new THREE.Vector3(x + 0.5, y + 0.5, z + 0.5);
    const pull = dropPos.clone().sub(from);
    for (let i = 0; i < 6; i++) {
      this.fx.spawnParticle(
        from.clone(),
        pull.clone().multiplyScalar(1.4 + Math.random() * 0.6)
          .add(new THREE.Vector3((Math.random() - 0.5) * 0.6, 0.4, (Math.random() - 0.5) * 0.6)),
        0xffb060, 0.02 + Math.random() * 0.01, 0.35, false,
      );
    }

    this.itemDrops.spawn(outcome.itemId, dropPos.clone(), new THREE.Vector3(
      (Math.random() - 0.5) * 0.4, 0.6, (Math.random() - 0.5) * 0.4));
    this.sound.playBreak(d.sound);
    this.blocksMined++;
  }

  private removeFloatingPlantsAbove(x: number, y: number, z: number): void {
    let cy = y + 1;
    while (true) {
      const id = this.world.getBlockRaw(x, cy, z);
      if (id === -1 || id === B.AIR) return;
      const d = DEFS[id];
      if (!d || d.cross !== true) return;
      this.world.setBlock(x, cy, z, B.AIR);
      if (id === B.TORCH) this.torchLights.remove(x, cy, z);
      this.particles.burst(x + 0.5, cy + 0.5, z + 0.5, d.colors, 8, 1.6);
      this.sound.playBreak(d.sound);
      this.dropBlock(id, new THREE.Vector3(x + 0.5, cy + 0.5, z + 0.5));
      cy++;
    }
  }

  private detachTorchesSupportedBy(bx: number, by: number, bz: number, drop: boolean): void {
    const popped = this.torchLights.detachSupportedBy(bx, by, bz);
    for (const [tx, ty, tz] of popped) {
      if (this.world.getBlockRaw(tx, ty, tz) === B.TORCH) this.world.setBlock(tx, ty, tz, B.AIR);
      this.particles.burst(tx + 0.5, ty + 0.55, tz + 0.5, DEFS[B.TORCH].colors, 10, 2);
      this.sound.playBreak('wood');
      if (drop) this.dropBlock(B.TORCH, new THREE.Vector3(tx + 0.5, ty + 0.5, tz + 0.5));
    }
  }

  private finalizeBlockRemoval(x: number, y: number, z: number, id: number, drop = true): void {
    if (id === B.TORCH) this.torchLights.remove(x, y, z);
    this.detachTorchesSupportedBy(x, y, z, drop);
    this.removeFloatingPlantsAbove(x, y, z);
    this.spillMachineOnBreak(x, y, z, id);
    this.enemies.notifyWorldChanged(new THREE.Vector3(x + 0.5, y + 0.5, z + 0.5));
  }


  openCrafting(table: boolean): void {
    if (table) this.inventory.setCraftSize(3);
    else this.inventory.setCraftSize(2);
    this.toggleInventory(true);
  }

  takeCraftResult(times: number): boolean {
    const inv = this.inventory;
    const recipe = matchCraft(inv.craftCells, inv.craftSize);
    if (!recipe) return false;
    const s = inv.craftSize;
    const possible = Math.min(times, craftableCount(inv.craft, s));
    if (possible <= 0) return false;
    const base = recipe.output;
    const out: SlotItem = base.kind === 'weapon'
      ? { ...base }
      : { ...base, count: (base.count ?? 1) * possible };
    if (!inv.canAdd(out)) return false;
    for (let i = 0; i < s * s; i++) {
      const it = inv.craft[i];
      if (it && it.kind === 'block') {
        it.count -= possible;
        if (it.count <= 0) inv.craft[i] = null;
      }
    }
    inv.addItem(out);
    this.sound.playPlace('wood');
    return true;
  }

  craftRecipe(id: string, times: number): number {
    const recipe = RECIPES.find((r) => r.id === id);
    if (!recipe || times <= 0) return 0;
    const inv = this.inventory;

    const need = new Map<number, number>();
    for (const ing of recipeIngredients(recipe))
      need.set(ing.blockId, (need.get(ing.blockId) ?? 0) + 1);

    let possible = times;
    for (const [bid, per] of need)
      possible = Math.min(possible, Math.floor(inv.countBlock(bid) / per));
    if (possible <= 0) return 0;

    const base = recipe.output;
    const out: SlotItem = base.kind === 'weapon'
      ? { ...base }
      : { ...base, count: (base.count ?? 1) * possible };
    if (!inv.canAdd(out)) return 0;

    for (const [bid, per] of need) {
      let left = per * possible;
      for (const arr of [inv.hotbar, inv.mainInv]) {
        for (let i = 0; i < arr.length && left > 0; i++) {
          const s = arr[i];
          if (s && s.kind === 'block' && s.blockId === bid) {
            const take = Math.min(s.count, left);
            s.count -= take; left -= take;
            if (s.count <= 0) arr[i] = null;
          }
        }
      }
    }
    inv.addItem(out);
    this.sound.playPlace('wood');
    return possible;
  }


  get openFurnace(): FurnaceState | null {
    return this.openFurnaceKey ? this.furnaces.get(this.openFurnaceKey) ?? null : null;
  }

  private machineKindAt(x: number, y: number, z: number): MachineKind {
    const id = this.world.getBlockRaw(x, y, z);
    if (id === B.FURNACE || id === B.FURNACE_LIT) return MachineKind.Furnace;
    if (id === B.CRAFTING_TABLE) return MachineKind.CraftingTable;
    return MachineKind.None;
  }

  private furnaceStateAt(x: number, y: number, z: number): FurnaceState {
    const key = machineKey(x, y, z);
    let state = this.furnaces.get(key);
    if (!state) {
      state = newFurnace();
      this.furnaces.set(key, state);
    }
    return state;
  }

  private craftingStateAt(x: number, y: number, z: number): CraftingTableState {
    const key = machineKey(x, y, z);
    let state = this.craftingTables.get(key);
    if (!state) {
      state = newCraftingTable();
      this.craftingTables.set(key, state);
    }
    return state;
  }

  private openFurnaceAt(x: number, y: number, z: number): void {
    const k = machineKey(x, y, z);
    this.furnaceStateAt(x, y, z);
    this.openFurnaceKey = k;
    this.craftingOpen = false;
    this.inventoryOpen = false;
    if (document.pointerLockElement === this.canvas) document.exitPointerLock();
    this.events.onStats(this.buildStats());
  }

  closeFurnace(): void {
    this.openFurnaceKey = null;
    this.requestLock();
    this.events.onStats(this.buildStats());
  }

  private rewardCoins(e: Enemy): void {
    const gain = COIN_REWARDS[e.cfg.id] ?? 12;
    this.coins += gain;
    saveCoins(this.coins);
    this.coinSeq++;
    this.lastCoinGain = gain;
    this.fpsAudio.coin();
  }

  private updateMerchantProximity(): void {
    if (this.dead || this.piloting) {
      this.nearMerchant = false;
      this.nearMerchantEnemy = null;
      return;
    }
    const p = this.player.pos;
    let best: Enemy | null = null;
    let bestD = TRADE_DISTANCE;
    for (const e of this.enemies.enemies) {
      if (!e.alive || e.cfg.id !== 'merchant' || e.state !== 'idle' || e.alerted) continue;
      const dx = C.wrapDelta(e.pos.x - p.x, C.WORLD_SIZE);
      const dz = C.wrapDelta(e.pos.z - p.z, C.WORLD_SIZE);
      if (Math.abs(e.pos.y - p.y) > 3) continue;
      const d = Math.hypot(dx, dz);
      if (d < bestD) { best = e; bestD = d; }
    }
    this.nearMerchantEnemy = best;
    this.nearMerchant = !!best;
    if (best) best.tradeFaceT = 0.4;
  }

  private updateShop(): void {
    const m = this.shopEnemy;
    if (!m) return;
    const p = this.player.pos;
    const dx = C.wrapDelta(m.pos.x - p.x, C.WORLD_SIZE);
    const dz = C.wrapDelta(m.pos.z - p.z, C.WORLD_SIZE);
    const stale =
      !m.alive || m.state !== 'idle' || m.alerted ||
      this.dead || this.piloting ||
      Math.hypot(dx, dz) > TRADE_DISTANCE * 1.6;
    if (stale) this.closeShop();
  }

  private openShop(): void {
    const m = this.nearMerchantEnemy;
    if (!m || this.shopEnemy) return;
    this.shopEnemy = m;
    this.shopStock = generateMerchantStock(() => Math.random());
    this.shopSellOpen = false;
    m.tradeFaceT = 1e5;
    this.inventoryOpen = false;
    this.craftingOpen = false;
    if (this.openFurnaceKey) this.openFurnaceKey = null;
    if (document.pointerLockElement === this.canvas) document.exitPointerLock();
    this.events.onStats(this.buildStats());
  }

  closeShop(): void {
    if (!this.shopEnemy) return;
    this.shopEnemy.tradeFaceT = 0;
    this.shopEnemy = null;
    this.requestLock();
    this.events.onStats(this.buildStats());
  }

  buyShopItem(id: string): boolean {
    const item = SHOP_ITEMS.find((i) => i.id === id);
    const m = this.shopEnemy;
    if (!item || !m || !m.alive || m.state !== 'idle') return false;

    const stock = this.shopStock.find((s) => s.itemId === id);
    if (stock && stock.quantity <= 0) { this.fpsAudio.deny(); return false; }

    if (this.coins < item.price) { this.fpsAudio.deny(); return false; }

    const inv = this.inventory;
    const goods = item.goods;
    if (!inv.canAdd(goods)) { this.fpsAudio.deny(); return false; }
    inv.addItem(goods);

    if (stock) stock.quantity--;

    this.coins -= item.price;
    saveCoins(this.coins);
    this.coinSeq++;
    this.lastCoinGain = -item.price;
    this.fpsAudio.purchase();
    this.events.onStats(this.buildStats());
    return true;
  }

  toggleShopSell(open?: boolean): void {
    if (!this.shopEnemy) return;
    this.shopSellOpen = open !== undefined ? open : !this.shopSellOpen;
    this.events.onStats(this.buildStats());
  }

  sellShopItem(ref: { isHotbar: boolean; index: number }, amount: number): boolean {
    const m = this.shopEnemy;
    if (!m || !m.alive || m.state !== 'idle') return false;

    const inv = this.inventory;
    const arr = ref.isHotbar ? inv.hotbar : inv.mainInv;
    const item = arr[ref.index];
    if (!item) return false;

    if (item.kind === 'weapon') return false;

    let pricePerUnit: number;
    let sellCount: number;
    if (item.kind === 'block') {
      pricePerUnit = getBlockSellPrice(item.blockId);
      sellCount = amount === 0 ? item.count : Math.min(amount, item.count);
    } else {
      pricePerUnit = getFoodSellPrice(item.foodId);
      sellCount = amount === 0 ? item.count : Math.min(amount, item.count);
    }
    if (sellCount <= 0 || pricePerUnit <= 0) return false;

    const totalGain = sellCount * pricePerUnit;

    item.count -= sellCount;
    if (item.count <= 0) arr[ref.index] = null;

    this.coins += totalGain;
    saveCoins(this.coins);
    this.coinSeq++;
    this.lastCoinGain = totalGain;
    this.fpsAudio.coin();
    this.events.onStats(this.buildStats());
    return true;
  }

  furnaceTransfer(slot: 'input' | 'fuel' | 'output', all: boolean): void {
    const st = this.openFurnace;
    if (!st) return;
    const inv = this.inventory;
    const held = st[slot];

    if (held) {
      const take = all ? held : { ...held, count: held.kind === 'weapon' ? 1 : 1 } as SlotItem;
      if (all) {
        if (inv.canAdd(held)) { inv.addItem(held); st[slot] = null; }
      } else if (held.kind !== 'weapon') {
        if (inv.canAdd({ ...held, count: 1 })) {
          inv.addItem({ ...held, count: 1 });
          held.count -= 1;
          if (held.count <= 0) st[slot] = null;
        }
      } else if (inv.canAdd(take)) { inv.addItem(take); st[slot] = null; }
      this.events.onStats(this.buildStats());
      return;
    }

    if (slot === 'output') return;

    const sel = inv.hotbar[this.sel];
    if (!sel || sel.kind !== 'block') return;
    const ok = slot === 'fuel' ? isFuel(sel.blockId) : !!smeltResult(sel.blockId);
    if (!ok) return;
    const n = all ? sel.count : 1;
    st[slot] = { kind: 'block', blockId: sel.blockId, count: n };
    sel.count -= n;
    if (sel.count <= 0) { inv.hotbar[this.sel] = null; this.selectSlot(this.sel, true); }
    this.events.onStats(this.buildStats());
  }

  furnaceQuickMove(ref: { isHotbar: boolean; isCraft?: boolean; index: number }): boolean {
    const st = this.openFurnace;
    if (!st) return false;
    const inv = this.inventory;
    const item = inv.getItem(ref);
    if (!item || item.kind !== 'block') return false;

    const target: 'input' | 'fuel' | null =
      smeltResult(item.blockId) ? 'input' :
      isFuel(item.blockId) ? 'fuel' : null;
    if (!target) return false;

    const cur = st[target];
    if (cur && (cur.kind !== 'block' || cur.blockId !== item.blockId || cur.count >= 64)) return false;

    const space = cur && cur.kind === 'block' ? 64 - cur.count : 64;
    const n = Math.min(space, item.count);
    if (n <= 0) return false;

    if (cur && cur.kind === 'block') cur.count += n;
    else st[target] = { kind: 'block', blockId: item.blockId, count: n };
    item.count -= n;
    if (item.count <= 0) inv.setItem(ref, null);

    this.syncHotbarMode();
    this.events.onStats(this.buildStats());
    return true;
  }

  private updateFurnaces(dt: number): void {
    for (const [k, st] of this.furnaces) {
      const at = parseMachineKey(k);
      if (!at) {
        this.furnaces.delete(k);
        continue;
      }
      const [x, y, z] = at;
      const legacy = drainFurnaceOutput(st);
      if (legacy) this.machineSink.emitAbove(x, y, z, legacy.id, legacy.count);
      const wasLit = st.burn > 0;
      const out = this.furnaceTickOut;
      tickFurnace(st, dt, out);
      if (out.producedCount > 0) {
        this.machineSink.emitAbove(x, y, z, out.producedId, out.producedCount);
      }
      const lit = st.burn > 0;
      if (lit !== wasLit) {
        const cur = this.world.getBlockRaw(x, y, z);
        if (cur === B.FURNACE || cur === B.FURNACE_LIT) {
          this.world.setBlock(x, y, z, lit ? B.FURNACE_LIT : B.FURNACE);
        }
      }
      if (furnaceIdle(st) && k !== this.openFurnaceKey) this.furnaces.delete(k);
    }
    this.updateCraftingTableGc();
  }

  private updateCraftingTableGc(): void {
    for (const [key, state] of this.craftingTables) {
      if (key !== this.openCraftingKey && craftingTableIdle(state)) this.craftingTables.delete(key);
    }
  }

  toggleInventory(open?: boolean): void {
    const want = open !== undefined ? open : !this.inventoryOpen;
    if (want) this.craftingOpen = false;
    this.inventoryOpen = want;
    if (want) {
      if (document.pointerLockElement === this.canvas) document.exitPointerLock();
    } else {
      this.requestLock();
    }
    this.events.onStats(this.buildStats());
  }

  openCraftingTable(x?: number, y?: number, z?: number): void {
    this.openCraftingKey = x === undefined || y === undefined || z === undefined
      ? null
      : machineKey(x, y, z);
    if (this.openCraftingKey) this.craftingStateAt(x!, y!, z!);
    this.craftingOpen = true;
    this.inventoryOpen = false;
    this.inventory.setCraftSize(3);
    if (document.pointerLockElement === this.canvas) document.exitPointerLock();
    this.events.onStats(this.buildStats());
  }

  get openCraftingState(): CraftingTableState | null {
    return this.openCraftingKey ? this.craftingTables.get(this.openCraftingKey) ?? null : null;
  }

  get openCraftingCoords(): [number, number, number] | null {
    return this.openCraftingKey ? parseMachineKey(this.openCraftingKey) : null;
  }

  selectCraftingBlueprint(recipeId: string | null): void {
    const state = this.openCraftingState;
    const at = this.openCraftingCoords;
    if (!state || !at) return;
    for (const item of setCraftingBlueprint(state, recipeId)) {
      this.machineSink.emitAbove(at[0], at[1], at[2], item.id, item.count);
    }
    this.events.onStats(this.buildStats());
  }

  closeCraftingTable(): void {
    this.craftingOpen = false;
    this.openCraftingKey = null;
    const inv = this.inventory;
    for (let i = 0; i < inv.craft.length; i++) {
      const it = inv.craft[i];
      if (it) { inv.addItem(it); inv.craft[i] = null; }
    }
    inv.setCraftSize(2);
    this.requestLock();
    this.events.onStats(this.buildStats());
  }

  private spillMachineOnBreak(x: number, y: number, z: number, id: number): void {
    const key = machineKey(x, y, z);
    if (id === B.FURNACE || id === B.FURNACE_LIT) {
      const state = this.furnaces.get(key);
      if (state) {
        for (const item of spillFurnace(state)) {
          this.machineSink.emitAbove(x, y, z, item.id, item.count);
        }
        this.furnaces.delete(key);
      }
      if (this.openFurnaceKey === key) this.openFurnaceKey = null;
      return;
    }
    if (id === B.CRAFTING_TABLE) {
      const state = this.craftingTables.get(key);
      if (state) {
        for (const item of spillCrafting(state)) {
          this.machineSink.emitAbove(x, y, z, item.id, item.count);
        }
        this.craftingTables.delete(key);
      }
      if (this.openCraftingKey === key) {
        this.openCraftingKey = null;
        this.craftingOpen = false;
      }
    }
  }

  toggleEnemies(enabled?: boolean): void {
    this.enemiesEnabled = enabled !== undefined ? enabled : !this.enemiesEnabled;
    this.enemies.setEnabled(this.enemiesEnabled);
  }

  syncHotbarMode(): void {
    this.selectSlot(this.sel, true);
  }

  private selectSlot(i: number, force = false): void {
    if (i < 0 || i >= 6 || this.dead) return;
    if (i === this.sel && !force) return;
    this.sel = i;
    this.sound.playClick();
    this.events.onSelect(i);
    this.switchAt = Date.now();
    this.eating = false;
    this.eatT = 0;

    const item = this.inventory.hotbar[i];
    if (item && item.kind === 'weapon' && item.weaponId === 'laser') {
      this.toolMode = 'laser';
      this.weapons.setHolstered(true);
    } else if (item && item.kind === 'weapon') {
      this.toolMode = 'weapon';
      this.weapons.setHolstered(false);
      this.weapons.switchTo(item.weaponId);
    } else if (item && item.kind === 'block') {
      this.toolMode = 'block';
      this.weapons.setHolstered(true);
      const worldId = FROM_FPS[item.blockId] ?? B.STONE;
      if (worldId === B.TORCH) this.heldBlock.showTorch();
      else this.heldBlock.setGeometry(this.blockGeometry(worldId));
    } else if (item && item.kind === 'food') {
      this.toolMode = 'food';
      this.weapons.setHolstered(true);
    } else {
      this.toolMode = 'barehand';
      this.weapons.setHolstered(true);
    }
    this.target = null;
    this.breakT = 0;
    this.crack.visible = false;
    this.statT = 0;
  }


  private throwHeldItem(): void {
    if (this.dead || this.piloting || this.spaceExited || this.throwCd > 0) return;
    const item = this.inventory.hotbar[this.sel];
    if (!item) { this.sound.playClick(); return; }
    this.throwCd = 0.35;

    const eye = this.player.eye();
    this.camera.getWorldDirection(this.aimDir);
    this.dropPos.set(
      eye.x + this.aimDir.x * 0.6,
      eye.y - 0.12 + this.aimDir.y * 0.4,
      eye.z + this.aimDir.z * 0.6,
    );
    this.dropVel.copy(this.aimDir).multiplyScalar(6.8).add(this.player.vel).add(this.dropLift);
    this.fpsAudio.whoosh();

    if (item.kind === 'weapon') {
      this.inventory.hotbar[this.sel] = null;
      this.itemDrops.spawnItem({ kind: 'weapon', weaponId: item.weaponId }, this.dropPos, this.dropVel);
    } else if (item.kind === 'block') {
      this.inventory.consumeBlock({ isHotbar: true, index: this.sel });
      this.itemDrops.spawn(item.blockId, this.dropPos, this.dropVel);
    } else if (item.kind === 'food') {
      this.inventory.consumeAt({ isHotbar: true, index: this.sel }, 1);
      this.itemDrops.spawnItem({ kind: 'food', foodId: item.foodId, count: 1 }, this.dropPos, this.dropVel);
    }
    this.syncHotbarMode();
  }

  private hitTarget(t: Target, dir: THREE.Vector3) {
    t.wobbleX.impulse(THREE.MathUtils.clamp(-dir.y * 30, -8, 8) + THREE.MathUtils.randFloatSpread(4));
    t.wobbleZ.impulse(THREE.MathUtils.randFloatSpread(9));
    t.flash = 1;
    this.fpsAudio.ding();
    this.targetsHit++;
    this.hitSeq++;
  }


  requestLock(): void {
    this.sound.ensure();
    this.fpsAudio.unlock();
    if (document.pointerLockElement !== this.canvas) {
      try {
        const p = this.canvas.requestPointerLock() as unknown as Promise<void> | undefined;
        if (p && typeof p.catch === 'function') p.catch(() => undefined);
      } catch {
      }
    }
  }

  private addListeners(): void {
    document.addEventListener('pointerlockchange', this.onLockChange);
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    document.addEventListener('mousemove', this.onMouseMove);
    document.addEventListener('mousedown', this.onMouseDown);
    document.addEventListener('mouseup', this.onMouseUp);
    window.addEventListener('wheel', this.onWheel, { passive: false });
    this.canvas.addEventListener('contextmenu', this.onContextMenu);
  }

  private removeListeners(): void {
    document.removeEventListener('pointerlockchange', this.onLockChange);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    document.removeEventListener('mousemove', this.onMouseMove);
    document.removeEventListener('mousedown', this.onMouseDown);
    document.removeEventListener('mouseup', this.onMouseUp);
    window.removeEventListener('wheel', this.onWheel);
    this.canvas.removeEventListener('contextmenu', this.onContextMenu);
  }

  private onContextMenu = (e: Event): void => e.preventDefault();

  private onLockChange = (): void => {
    this.locked = document.pointerLockElement === this.canvas;
    if (this.locked) {
      this.everLocked = true;
      if (this.toolMode === 'weapon') this.weapons.setHolstered(false);
    } else {
      this.input = { forward: false, back: false, left: false, right: false, jump: false, sprint: false, crouch: false };
      this.mouse.left = false;
      this.mouse.right = false;
      this.breakT = 0;
      this.crack.visible = false;
      this.weapons.setAllVisible(false);
      if (this.piloting) this.sound.setShip(0, 0);
    }
    this.events.onLock(this.locked);
  };

  private onKeyDown = (e: KeyboardEvent): void => {
    if (e.code === 'Tab') {
      e.preventDefault();
      if (this.shopEnemy) { this.closeShop(); return; }
      if (this.openFurnaceKey) { this.closeFurnace(); return; }
      if (this.craftingOpen) { this.closeCraftingTable(); return; }
      this.toggleInventory();
      return;
    }
    if (e.code === 'Escape' && this.shopEnemy) {
      this.closeShop();
      return;
    }
    if (e.code === 'Escape' && this.openFurnaceKey) {
      this.closeFurnace();
      return;
    }
    if (e.code === 'Escape' && this.craftingOpen) {
      this.closeCraftingTable();
      return;
    }
    if (!this.locked) return;
    switch (e.code) {
      case 'KeyW': this.input.forward = true; break;
      case 'KeyS': this.input.back = true; break;
      case 'KeyA': this.input.left = true; break;
      case 'KeyD': this.input.right = true; break;
      case 'Space': this.input.jump = true; e.preventDefault(); break;
      case 'ShiftLeft': case 'ShiftRight': this.input.sprint = true; break;
      case 'ControlLeft': case 'ControlRight': this.input.crouch = true; e.preventDefault(); break;
      case 'KeyM': this.sound.setMuted(!this.sound.muted); break;
      case 'KeyQ':
        e.preventDefault();
        this.throwHeldItem();
        break;
      case 'KeyR':
        if (this.toolMode === 'weapon') this.weapons.startReload();
        break;
      case 'KeyF':
        if (this.toolMode === 'weapon') this.weapons.inspect();
        break;
      case 'KeyE':
        if (this.piloting) this.exitShip();
        else if (this.nearMerchantEnemy) this.openShop();
        else if (this.ship && this.ship.distanceTo(this.player.eye()) < 6) this.boardShip();
        else {
          const eye = this.player.eye();
          this.camera.getWorldDirection(this.aimDir);
          const hit = raycastVoxel(this.world, eye.x, eye.y, eye.z,
            this.aimDir.x, this.aimDir.y, this.aimDir.z, 5);
          if (hit && (isConveyor(hit.id) || isInserter(hit.id) || isLaserMiner(hit.id))) {
            e.preventDefault();
            this.sound.playClick();
            this.rotateConveyor(hit.x, hit.y, hit.z, hit.id);
          }
        }
        break;
      default:
        if (e.code.startsWith('Digit') || e.code.startsWith('Numpad')) {
          const n = parseInt(e.code.replace('Digit', '').replace('Numpad', ''), 10);
          if (n >= 1 && n <= 6) {
            e.preventDefault();
            this.selectSlot(n - 1);
          }
        }
    }
  };

  private onKeyUp = (e: KeyboardEvent): void => {
    switch (e.code) {
      case 'KeyW': this.input.forward = false; break;
      case 'KeyS': this.input.back = false; break;
      case 'KeyA': this.input.left = false; break;
      case 'KeyD': this.input.right = false; break;
      case 'Space': this.input.jump = false; break;
      case 'ShiftLeft': case 'ShiftRight': this.input.sprint = false; break;
      case 'ControlLeft': case 'ControlRight': this.input.crouch = false; break;
    }
  };

  private onMouseMove = (e: MouseEvent): void => {
    if (!this.locked) return;
    const s = 0.0022 * this.weapons.sensFactor();
    this.player.yaw -= e.movementX * s;
    this.player.pitch -= e.movementY * s;
    this.player.pitch = Math.max(-1.55, Math.min(1.55, this.player.pitch));
    this.weapons.notifyLook(e.movementX, e.movementY);
  };

  private onMouseDown = (e: MouseEvent): void => {
    if (!this.locked || this.piloting) return;
    if (e.button === 0) {
      this.mouse.left = true;
      if (this.toolMode === 'laser' || this.toolMode === 'barehand') this.breakT = 0;
    } else if (e.button === 2) {
      const eye = this.player.eye();
      this.camera.getWorldDirection(this.aimDir);
      const hit = raycastVoxel(this.world, eye.x, eye.y, eye.z,
        this.aimDir.x, this.aimDir.y, this.aimDir.z, 5);
      if (hit && hit.id === B.CRAFTING_TABLE) {
        this.mouse.right = false;
        this.openCraftingTable(hit.x, hit.y, hit.z);
        return;
      }
      if (hit && (hit.id === B.FURNACE || hit.id === B.FURNACE_LIT)) {
        this.mouse.right = false;
        this.openFurnaceAt(hit.x, hit.y, hit.z);
        return;
      }
      this.mouse.right = true;
    }
  };

  private onMouseUp = (e: MouseEvent): void => {
    if (e.button === 0) {
      this.mouse.left = false;
      this.breakT = 0;
      this.crack.visible = false;
    } else if (e.button === 2) this.mouse.right = false;
  };

  private wheelAcc = 0;

  private onWheel = (e: WheelEvent): void => {
    if (!this.locked) return;
    e.preventDefault();
    this.wheelAcc += e.deltaY > 0 ? 1 : -1;
  };

  private flushWheel(): void {
    if (this.wheelAcc === 0) return;
    const step = this.wheelAcc > 0 ? 1 : -1;
    this.wheelAcc = 0;
    this.selectSlot((this.sel + step + 6) % 6, true);
  }


  private resize = (): void => {
    const w = this.canvas.clientWidth || window.innerWidth;
    const h = this.canvas.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h, false);
    this.mainRT?.setSize(w, h);
    this.lightingRT?.setSize(w, h);
    this.fogRT?.setSize(w, h);
    this.volumetricRT?.setSize(w, h);
    this.giRT?.setSize(Math.max(1, Math.floor(w / 2)), Math.max(1, Math.floor(h / 2)));
    this.blurRT?.setSize(Math.max(1, Math.floor(w / 2)), Math.max(1, Math.floor(h / 2)));
    this.lumenLite?.setSize(w, h);
    this.volumetricLight?.setSize(w, h);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  };

  private tick = (): void => {
    if (this.disposed) return;
    const frameStart = performance.now();
    const dt = Math.min(this.clock.getDelta(), 0.05);
    const fpsNow = 1 / Math.max(dt, 1e-4);
    this.fps += (fpsNow - this.fps) * 0.06;
    this.time += dt;

    if (this.locked) this.tickPlay(dt);
    else this.tickMenuCamera(dt);
    if (this.dmgFollowT > 0) this.dmgFollowT = Math.max(0, this.dmgFollowT - dt);
    if (this.throwCd > 0) this.throwCd -= dt;

    if (!this.spaceExited && this.piloting && this.ship.pos.y > SPACE_ALTITUDE) {
      this.spaceExited = true;
      this.weapons.setAllVisible(false);
      this.bodyGroup.visible = false;
      this.heldFood.visible = false;
      this.events.onEnterSpace?.(this.theme);
    }

    WATER_TIME.value += dt;
    if (this.textures) {
      this.textures.water.offset.x += dt * 0.003;
      this.textures.water.offset.y += dt * 0.006;
      animateConveyorTiles(this.textures, this.time);
    }
    this.dtFluid += dt;
    if (this.locked && performance.now() < frameStart + 8.0) {
      this.fluid.update(this.dtFluid);
      this.dtFluid = 0;
    } else if (this.dtFluid > 0.1) {
      if (this.locked) this.fluid.update(this.dtFluid);
      this.dtFluid = 0;
    }
    if (this.locked) {
      let streamX = this.player.pos.x;
      let streamZ = this.player.pos.z;
      if (this.piloting && this.ship) {
        streamX = this.ship.pos.x + this.ship.vel.x * 0.7;
        streamZ = this.ship.pos.z + this.ship.vel.z * 0.7;
      }
      const simLeft = (frameStart + 8.0) - performance.now();
      const frameBudget = Math.max(1.0, Math.min(5.5, simLeft));
      this.world.update(streamX, streamZ, frameBudget);
      this.world.syncChunkOffsets(this.camera.position.x, this.camera.position.z);
      if (this.ship) this.ship.syncRender(this.camera.position);

      const fpx = this.player.pos.x, fpy = this.player.pos.y, fpz = this.player.pos.z;
      const mdx = C.wrapDelta(fpx - this.lastFieldX, C.WORLD_SIZE);
      const mdz = C.wrapDelta(fpz - this.lastFieldZ, C.WORLD_SIZE);
      const fieldMoved = !(mdx * mdx + mdz * mdz < 64)
                      || !(Math.abs(fpy - this.lastFieldY) < 4);
      if (fieldMoved) {
        this.flow.invalidate();
        this.lastFieldX = fpx; this.lastFieldY = fpy; this.lastFieldZ = fpz;
      }
      this.flow.update(fpx, fpy, fpz, this.world);
      if (this.ship && !this.piloting) this.ship.updateParked(dt);
    }
    if (this.locked && (!this.piloting || this.shipAltitude() < 26)) {
      this.enemies.update(dt);
    }
    if (this.locked) {
      this.updateFurnaces(dt);
      if (this.openFurnaceKey) this.events.onStats(this.buildStats());
      this.updateMerchantProximity();
      this.updateShop();

      const cosmeticsOk = performance.now() < frameStart + 8.0;
      this.dtParticles += dt;
      this.dtSky += dt;
      if (cosmeticsOk || this.dtParticles > 0.1) {
        this.particles.update(this.dtParticles); this.dtParticles = 0;
        this.sky.update(this.dtSky, this.camera.position); this.dtSky = 0;
      }
    }
    this.sound.update(dt, this.sky.isDay);
    if (this.locked) {
      this.enemies.setNight(this.sky.sunElev < 0.02);
    }

    if (this.locked) {
      const nightFog = 1 - THREE.MathUtils.smoothstep(this.sky.sunElev, -0.05, 0.11);
      const directT = THREE.MathUtils.smoothstep(this.sky.dayFactor, 0.18, 0.45);

      const mistK = nightFog * 0.85;
      const mist = this.fogScratch.copy(NIGHT_MIST).lerp(this.sky.skyColor, 0.25);
      FOG_UNIFORMS.uSkyFogColor.value.copy(mist);
      FOG_UNIFORMS.uSkyFog.value = mistK;
      FOG_UNIFORMS.uFogColor.value.copy(this.sky.skyColor).lerp(mist, mistK);

      FOG_UNIFORMS.uFogSunColor.value.copy(this.sky.moonColor).lerp(this.sky.sunColor, directT);
      FOG_UNIFORMS.uFogSunDir.value.copy(this.sky.sunDirection);

      FOG_UNIFORMS.uFogDensity.value = 0.012 + nightFog * 0.072;
      FOG_UNIFORMS.uFogHeight.value = this.world.gen.sea + 2;
      FOG_UNIFORMS.uFogFalloff.value = 46 - nightFog * 18;
      FOG_UNIFORMS.uFogInscatter.value = 0.04 + (1 - nightFog) * 0.55;
      FOG_UNIFORMS.uFogStart.value = THREE.MathUtils.lerp(8, 1.5, nightFog);

      const maxRange = (C.VIEW_DISTANCE + 0.75) * C.CHUNK_SIZE;
      const flyAmt = this.piloting
        ? THREE.MathUtils.smoothstep(this.shipAltitude(), 10, 40)
        : THREE.MathUtils.smoothstep(this.camera.position.y - this.world.gen.sea, 16, 46);
      const blend = Math.max(nightFog, flyAmt);
      FOG_UNIFORMS.uFarFogStart.value = THREE.MathUtils.lerp(maxRange * 0.48, maxRange * 0.32, blend);
      FOG_UNIFORMS.uFarFogEnd.value = THREE.MathUtils.lerp(maxRange * 0.92, maxRange * 0.78, blend);

      this.applyUnderwaterFx();
    }

    if (this.locked && this.volumetricLight) {
      this.volumetricLight.lightWorldPosition.copy(this.sky.sunWorldPos);

      const elev = this.sky.sunElev;
      const moonUp = THREE.MathUtils.clamp(-elev, 0, 1);
      const angleFactor = THREE.MathUtils.clamp(0.75 - Math.abs(elev - 0.15) * 0.9, 0, 0.75);
      const sunI = angleFactor * 0.85;
      const moonI = 0.05 + moonUp * 0.09;

      const night = 1 - THREE.MathUtils.smoothstep(this.sky.dayFactor, 0.20, 0.44);
      this.volumetricLight.intensity = THREE.MathUtils.lerp(sunI, moonI, night);
      this.volumetricLight.discScale = THREE.MathUtils.lerp(85, 18, night);
      this.volumetricLight.tint.copy(this.sky.sunColor).lerp(this.sky.moonColor, night);
    }

    if (this.locked && this.bloom) {
      this.bloom.strength = 0.30 * THREE.MathUtils.smoothstep(this.sky.dayFactor, 0.0, 0.35);
    }

    if (this.locked && this.flashlight) {
      const canUse = !this.dead && !this.piloting;
      const nightAmt = 1 - THREE.MathUtils.smoothstep(this.sky.dayFactor, 0.05, 0.3);
      this.flashlight.intensity = canUse ? nightAmt * 2.4 : 0;
    }

    if (this.locked) {
      this.grassShadowT -= dt;
      if (this.grassShadowT <= 0) {
        this.grassShadowT = this.fps < 40 ? 0.5 : 0.25;
        const radius = this.piloting ? 0 : GRASS_SHADOW_RADIUS;
        if (this.world.updateGrassShadowCasters(this.camera.position.x, this.camera.position.z, radius)) {
          this.shadowCooldown = 0;
          if (this.renderer.shadowMap) this.renderer.shadowMap.needsUpdate = true;
        }
      }

      const p = this.player.pos;
      const moved = Math.abs(p.x - this.lastShadowX) > 2 || Math.abs(p.z - this.lastShadowZ) > 2;
      this.shadowCooldown -= dt;
      if (this.renderer.shadowMap && moved && this.shadowCooldown <= 0) {
        this.lastShadowX = p.x;
        this.lastShadowZ = p.z;
        this.shadowCooldown = this.piloting ? 0.75 : (this.fps < 40 ? 0.45 : 0.2);
        this.renderer.shadowMap.needsUpdate = true;
      }
    }

    if (this.locked) {
      this.reportStats(dt);
    }

    const simMs = performance.now() - frameStart;
    this.simMsEma += (simMs - this.simMsEma) * 0.15;
    {
      const sim = this.simMsEma;
      let want: 0 | 1 | 2 = this.postQ;
      if (sim > 11.0)            want = 2;
      else if (sim > 8.0)        want = 1;
      else if (sim < 4.8)        want = 0;
      else if (this.postQ === 2 && sim < 8.25)  want = 1;
      if (want !== this.postQ && performance.now() - this.postQAt > 250) {
        this.postQ = want;
        this.postQAt = performance.now();
      }
    }

    if (this.mainRT) {
      const q = this.postQ;

      this.renderer.setRenderTarget(this.mainRT);
      this.renderer.render(this.scene, this.camera);

      this.lumenLite!.configure(
        this.sky.skyColor,
        this.sky.sunColor,
        this.sky.sunDirection,
        this.sky.dayFactor,
        this.world.gen.sea,
      );
      this.lumenLite!.renderPipeline(this.renderer, this.mainRT, this.lightingRT!, this.giRT!, this.blurRT!);

      this.depthFogPass!.render(this.renderer, this.fogRT!, this.lightingRT!, this.mainRT.depthTexture);

      let finalTex: THREE.Texture = this.fogRT!.texture;

      this.dtBloom += dt;
      if (q < 2) {
        this.bloom!.render(this.renderer, this.fogRT!, this.fogRT!, this.dtBloom, false);
        this.dtBloom = 0;
      }

      if (q === 0) {
        this.volumetricLight!.render(this.renderer, this.volumetricRT!, this.fogRT!);
        finalTex = this.volumetricRT!.texture;
      }

      this.outputStage!.render(this.renderer, finalTex);
    } else {
      this.renderer.render(this.scene, this.camera);
    }

    if (performance.now() - frameStart < 10.0) {
      this.captureSnapshot(dt);
    }
  };

  private tickMenuCamera(dt: number): void {
    if (this.everLocked) {
      this.syncCamera(dt);
      this.laser.update(dt, { visible: false, firing: false, target: null, charge: 0, speed: 0 });
      this.heldBlock.update(dt, false, 0);
      this.heldFood.visible = false;
      return;
    }
    this.menuYaw += dt * 0.05;
    const r = 15;
    const cx = this.spawn.x + Math.cos(this.menuYaw) * r;
    const cz = this.spawn.z + Math.sin(this.menuYaw) * r;
    this.camera.position.set(cx, this.spawn.y + 9.5, cz);
    this.camera.lookAt(this.spawn.x, this.spawn.y + 2.5, this.spawn.z);
    this.laser.update(dt, { visible: false, firing: false, target: null, charge: 0, speed: 0 });
    this.heldBlock.update(dt, false, 0);
    this.heldFood.visible = false;
  }

  private boardShip(resetCamera = false): void {
    this.ship.ensureClearance(0.35);
    this.piloting = true;
    this.weapons.setAllVisible(false);
    this.laser.update(0, { visible: false, firing: false, target: null, charge: 0, speed: 0 });
    this.heldBlock.update(0, false, 0);
    this.heldFood.visible = false;
    this.bodyGroup.visible = false;
    if (resetCamera) {
      const yaw = this.player.yaw;
      const s = this.ship.imageNear(this.camera.position, this.tmpShipImg);
      this.flyCam.set(
        s.x + Math.sin(yaw) * 11,
        s.y + 2.3,
        s.z + Math.cos(yaw) * 11,
      );
      this.camera.position.copy(this.flyCam);
      this.tmpSeat.set(
        s.x - Math.sin(yaw) * 3.2,
        s.y + 1.0,
        s.z - Math.cos(yaw) * 3.2,
      );
      this.camera.lookAt(this.tmpSeat);
      this.fov = 75;
      this.camera.fov = 75;
      this.camera.updateProjectionMatrix();
    } else {
      this.flyCam.copy(this.camera.position);
    }
    this.highlight.visible = false;
    this.crack.visible = false;
    this.mouse.left = false;
    this.mouse.right = false;
    this.breakT = 0;
    this.sound.playBoard();
  }

  private exitShip(): void {
    this.piloting = false;
    this.spaceExited = false;
    this.sound.playDisembark();
    this.sound.stopShip();

    this.ship.recenter();

    const yaw = this.ship.yaw;
    const sx = this.ship.pos.x, sy = this.ship.pos.y, sz = this.ship.pos.z;
    let placed = false;
    for (const sign of [1, -1]) {
      if (placed) break;
      const px = C.wrapBlock(sx + Math.cos(yaw) * 4.2 * sign);
      const pz = C.wrapBlock(sz - Math.sin(yaw) * 4.2 * sign);
      const bx = Math.floor(px);
      const bz = Math.floor(pz);
      for (let y = Math.min(Math.floor(sy) + 8, 95); y > 2; y--) {
        if (this.world.isSolid(bx, y, bz)) continue;
        if (
          !this.world.isSolid(bx, y + 1, bz) &&
          this.world.isSolid(bx, y - 1, bz)
        ) {
          this.player.setSpawn(bx + 0.5, y, bz + 0.5);
          this.player.yaw = yaw;
          placed = true;
          break;
        }
      }
    }
    if (!placed) {
      this.player.setSpawn(C.wrapBlock(sx), sy + 3, C.wrapBlock(sz));
      this.player.yaw = yaw;
    }
    this.ship.settleHere();
    this.selectSlot(this.sel, true);
    this.snapCameraToEye();
    this.ship.syncRender(this.camera.position);
  }

  private shipAltitude(): number {
    if (!this.ship) return 0;
    const gy = this.world.highestY(Math.floor(this.ship.pos.x), Math.floor(this.ship.pos.z));
    return this.ship.pos.y - gy;
  }

  private snapCameraToEye(): void {
    const eye = this.player.eye();
    this.camera.position.copy(eye);
    this.camera.rotation.set(this.player.pitch, this.player.yaw, 0);
    this.fov = 75;
    this.camera.fov = 75;
    this.camera.updateProjectionMatrix();
  }

  private tickPilot(dt: number): void {
    const p = this.player;
    this.ship.updatePilot(dt, p.yaw, p.pitch, {
      forward: this.input.forward,
      back: this.input.back,
      left: this.input.left,
      right: this.input.right,
      up: this.input.jump,
      down: this.input.sprint,
    }, this.sound);

    if (this.ship.lastWrap.x !== 0 || this.ship.lastWrap.z !== 0) {
      this.flyCam.x += this.ship.lastWrap.x;  this.flyCam.z += this.ship.lastWrap.z;
      this.camera.position.x += this.ship.lastWrap.x;  this.camera.position.z += this.ship.lastWrap.z;
    }

    p.pos.set(this.ship.pos.x, this.ship.pos.y - 0.2, this.ship.pos.z);
    p.vel.set(0, 0, 0);
    p.inWater = false;
    p.headInWater = false;
    this.wasInWater = false;

    const yaw = p.yaw;
    const pitch = p.pitch;
    const cp = Math.cos(pitch);
    const fx = -Math.sin(yaw) * cp;
    const fyy = Math.sin(pitch);
    const fz = -Math.cos(yaw) * cp;
    this.aimDir.set(fx, fyy, fz);

    let dist = 11;
    for (let t = 0.75; t < 11.5; t += 0.5) {
      if (this.world.isSolid(
        Math.floor(this.ship.pos.x - fx * t),
        Math.floor(this.ship.pos.y + 1.2 - fyy * t),
        Math.floor(this.ship.pos.z - fz * t)
      )) {
        dist = t - 0.8;
        break;
      }
    }
    dist = Math.max(1.6, Math.min(11, dist));

    this.tmpCam.set(
      this.ship.pos.x - fx * dist,
      this.ship.pos.y + 2.3 - fyy * dist,
      this.ship.pos.z - fz * dist
    );
    this.flyCam.lerp(this.tmpCam, Math.min(1, 17 * dt));

    for (let i = 0; i < 16; i++) {
      if (!this.world.isSolid(
        Math.floor(this.flyCam.x),
        Math.floor(this.flyCam.y),
        Math.floor(this.flyCam.z)
      )) break;
      this.flyCam.x += (this.ship.pos.x - this.flyCam.x) * 0.2;
      this.flyCam.y += (this.ship.pos.y + 2.3 - this.flyCam.y) * 0.2 + 0.15;
      this.flyCam.z += (this.ship.pos.z - this.flyCam.z) * 0.2;
    }
    this.camera.position.copy(this.flyCam);

    this.tmpSeat.set(
      this.ship.pos.x + fx * 3.2,
      this.ship.pos.y + 1.0 + fyy * 3.2,
      this.ship.pos.z + fz * 3.2
    );
    this.camera.lookAt(this.tmpSeat);

    const targetFov = 75 + (this.ship.speed() / 28) * 7;
    this.fov += (targetFov - this.fov) * Math.min(1, 6 * dt);
    if (Math.abs(this.fov - this.camera.fov) > 0.05) {
      this.camera.fov = this.fov;
      this.camera.updateProjectionMatrix();
    }

    this.laser.update(dt, { visible: false, firing: false, target: null, charge: 0, speed: 0 });
    this.heldBlock.update(dt, false, 0);
    this.heldFood.visible = false;

    this.fx.update(dt);
  }

  private tickPlay(dt: number): void {
    this.flushWheel();
    if (this.piloting) {
      this.tickPilot(dt);
      return;
    }
    this.bodyGroup.visible = true;
    const p = this.player;
    this.prevVelY = p.vel.y;

    if (this.dead) {
      this.deadTimer += dt;
      const timeScale = THREE.MathUtils.lerp(0.35, 0.85, Math.min(1, this.deadTimer / 2.5));
      const sdt = dt * timeScale;
      this.fx.update(sdt);
      this.weapons.update(dt, this.time, false, false, false);
      this.updateDroppedWeapon(dt);
      this.itemDrops.update(sdt, this.player.pos);
      this.machines.update(sdt, this.player.pos);
      this.player.updateDeath(dt);
      this.player.applyDeathCamera(this.camera);
      if (this.deadTimer >= DEATH_DURATION) this.respawn();
      return;
    }

    p.update(dt, this.input);

    if (p.onGround) {
      const belowId = this.world.getBlockRaw(
        Math.floor(p.pos.x), Math.floor(p.pos.y - 0.05), Math.floor(p.pos.z));
      const dir = conveyorDir(belowId);
      if (dir) {
        const BELT_ACCEL = 46;
        p.vel.x += dir[0] * BELT_ACCEL * dt;
        p.vel.z += dir[1] * BELT_ACCEL * dt;
      }
    }

    if (p.pos.y < -12) p.setSpawn(this.spawn.x, this.spawn.y, this.spawn.z);

    if (p.onGround && !this.wasOnGround && this.prevVelY < -9.5) {
      this.sound.playLand(-this.prevVelY / 12);
    }
    this.wasOnGround = p.onGround;

    if (p.inWater && !this.wasInWater) this.sound.playSplash();
    this.wasInWater = p.inWater;

    const hs = p.horizontalSpeed();
    if (p.onGround && hs > 0.8 && !p.inWater) {
      this.walkAcc += hs * dt;
      if (this.walkAcc > 2.1) {
        this.walkAcc = 0;
        this.sound.playStep(p.groundSound());
      }
    } else this.walkAcc = Math.min(this.walkAcc, 1.9);

    if (p.onGround && hs > 0.5) this.bob += dt * hs * 1.6;

    this.syncCamera(dt);

    if (this.toolMode === 'weapon') {
      this.triggerDown = this.mouse.left && !this.prevLeft;
      this.adsHeld = this.mouse.right;
      this.highlight.visible = false;
      this.crack.visible = false;
      this.heldFood.visible = false;
      this.laser.update(dt, { visible: false, firing: false, target: null, charge: 0, speed: hs });
    } else if (this.toolMode === 'laser' || this.toolMode === 'barehand') {
      this.triggerDown = false;
      this.adsHeld = false;
      this.heldFood.visible = false;
      this.updateTarget();
      this.updateMining(dt);
    } else if (this.toolMode === 'food') {
      this.triggerDown = false;
      this.adsHeld = false;
      this.placeCd -= dt;
      this.updateFood(dt);
      this.laser.update(dt, { visible: false, firing: false, target: null, charge: 0, speed: hs });
    } else {
      this.triggerDown = false;
      this.adsHeld = false;
      this.heldFood.visible = false;
      this.updateTarget();
      this.placeCd -= dt;
      this.placeBlock();
      this.laser.update(dt, { visible: false, firing: false, target: null, charge: 0, speed: hs });
    }
    this.prevLeft = this.mouse.left;
    this.heldBlock.update(dt, this.toolMode === 'block', hs);

    const canWeapon = this.toolMode === 'weapon';
    this.weapons.update(
      dt,
      this.time,
      canWeapon && this.triggerDown,
      canWeapon && this.mouse.left,
      canWeapon && this.adsHeld
    );

    if (this.invulnT > 0) this.invulnT -= dt;
    this.fx.update(dt);
    this.itemDrops.update(dt, this.player.pos);
    this.machines.update(dt, this.player.pos);
    this.sim?.setLivePlayer(this.player.pos.x, this.player.pos.z);
    universeSim.tickActive(dt);

    this.torchLights.update(dt, this.camera.position);

    for (const t of this.targets) {
      t.wobbleX.update(dt);
      t.wobbleZ.update(dt);
      t.board.rotation.x = t.wobbleX.v * 0.06;
      t.board.rotation.z = t.wobbleZ.v * 0.06;
      t.board.rotation.y = t.wobbleZ.v * 0.02;
      if (t.flash > 0) {
        t.flash = Math.max(0, t.flash - dt * 4);
        t.boardMat.emissive.setScalar(t.flash * 0.3);
      }
    }

    this.bodyGroup.position.set(p.pos.x, p.pos.y, p.pos.z);
    this.bodyGroup.rotation.y = p.yaw;
    this.body.update(p.movePhase, Math.min(1, p.speedSmooth / 6.5), !p.onGround);
    const cs = 1 - p.crouchAmt * 0.3;
    this.bodyGroup.scale.set(1, cs, 1);
  }

  private adsHeld = false;

  private syncCamera(dt: number): void {
    const p = this.player;
    const bobY = Math.abs(Math.sin(this.bob)) * 0.055;
    const bobX = Math.cos(this.bob * 0.5) * 0.02;
    this.camera.position.set(
      p.pos.x + Math.cos(p.yaw) * bobX,
      p.pos.y + C.EYE_HEIGHT + bobY,
      p.pos.z + Math.sin(p.yaw) * bobX
    );
    const shakeX = Math.sin(this.time * 31) * p.shake;
    const shakeY = Math.cos(this.time * 27) * p.shake;
    const crouchEye = C.EYE_HEIGHT + (1.12 - C.EYE_HEIGHT) * p.crouchAmt;
    this.camera.position.y = p.pos.y + crouchEye + bobY;

    this.camera.rotation.set(p.pitch + p.recoilP + shakeX, p.yaw + p.recoilY + shakeY, 0);

    const ads = this.weapons.adsT;
    const def = this.weapons.def;
    let targetFov = 75 - (75 - def.adsFov) * ads;
    if (this.input.sprint && !p.crouching && p.horizontalSpeed() > C.WALK_SPEED + 0.4) {
      targetFov += 8 * (1 - ads);
    }
    this.fov += (targetFov - this.fov) * Math.min(1, 14 * dt);
    if (Math.abs(this.fov - this.camera.fov) > 0.05) {
      this.camera.fov = this.fov;
      this.camera.updateProjectionMatrix();
    }
  }


  private updateTarget(): void {
    this.camera.getWorldDirection(this.aimDir);
    const eye = this.player.eye();
    this.aimPoint.copy(eye);
    const hit = raycastVoxel(this.world, eye.x, eye.y, eye.z, this.aimDir.x, this.aimDir.y, this.aimDir.z, C.REACH);

    const changed =
      (hit === null) !== (this.target === null) ||
      (hit && this.target && (hit.x !== this.target.x || hit.y !== this.target.y || hit.z !== this.target.z));

    this.target = hit;
    if (changed) this.breakT = 0;

    if (hit) {
      this.highlight.position.set(hit.x + 0.5, hit.y + 0.5, hit.z + 0.5);
      this.highlight.visible = true;
      this.aimPoint.addScaledVector(this.aimDir, Math.max(0.01, hit.dist - 0.02));
    } else {
      this.highlight.visible = false;
      this.crack.visible = false;
    }
  }

  private updateMining(dt: number): void {
    const isLaser = this.toolMode === 'laser';
    const active = (isLaser || this.toolMode === 'barehand') && !this.dead;
    const speed = this.player.horizontalSpeed();
    const mineRate = isLaser ? 4 : 1;

    if (!active || !this.mouse.left || !this.target) {
      if (!this.target) this.crack.visible = false;
      this.breakT = 0;
      this.mineCharge = Math.max(0, this.mineCharge - dt * 1.6);
      this.laser.update(dt, {
        visible: active && isLaser, firing: false,
        target: this.target ? this.aimPoint : null,
        charge: 0, speed,
      });
      return;
    }

    const d = DEFS[this.target.id];
    if (!d || !canLaserBreak(this.target.id)) {
      this.breakT = 0;
      this.mineCharge = 0;
      this.crack.visible = false;
      this.laser.update(dt, { visible: isLaser, firing: false, target: this.aimPoint, charge: 0, speed });
      return;
    }

    this.mineCharge = Math.min(1, this.mineCharge + dt * 1.9);
    this.breakT += (dt / Math.max(0.05, d.hardness)) * mineRate;

    this.digSoundT -= dt;
    if (this.digSoundT <= 0) {
      this.digSoundT = 0.12;
      if (isLaser) this.fpsAudio.laserSizzle();
      else this.fpsAudio.foley('slap');
      this.particles.burst(
        this.aimPoint.x, this.aimPoint.y, this.aimPoint.z,
        d.colors, isLaser ? 2 : 1, isLaser ? 1.4 : 1.1,
      );
    }

    this.laser.update(dt, {
      visible: isLaser, firing: isLaser, target: this.aimPoint,
      charge: this.mineCharge, speed,
    });

    const stages = this.crackMats.length;
    if (stages > 0) {
      const stage = Math.min(stages - 1, Math.max(0, Math.floor(this.breakT * stages)));
      this.crack.material = this.crackMats[stage];
      this.crack.position.set(this.target.x + 0.5, this.target.y + 0.5, this.target.z + 0.5);
      this.crack.visible = true;
    }

    if (this.breakT < 1) return;

    const { x, y, z, id } = this.target;
    const outcome = harvestOutcome(id, TO_FPS);
    if (!outcome) {
      if (!this.world.destroyBlockAt(x, y, z)) return;
      this.particles.burst(x + 0.5, y + 0.5, z + 0.5, DEFS[id].colors, 18, 2.6);
      this.sound.playBreak(d.sound);
      this.dropBlock(id, new THREE.Vector3(x + 0.5, y + 0.5, z + 0.5));
      this.blocksMined++;
      this.finalizeBlockRemoval(x, y, z, id, true);
      this.breakT = 0;
      this.mineCharge = 0;
      this.crack.visible = false;
      this.target = null;
      return;
    }

    if (!outcome.destroy) {
      this.particles.burst(x + 0.5, y + 0.5, z + 0.5, DEFS[id].colors, 14, 2.4);
      this.sound.playBreak(d.sound);
      this.itemDrops.spawn(outcome.itemId, new THREE.Vector3(x + 0.5, y + 0.5, z + 0.5));
      this.blocksMined++;
      this.breakT = 0;
      this.mineCharge = 0;
      this.crack.visible = false;
      return;
    }

    if (!this.world.destroyBlockAt(x, y, z)) return;
    this.particles.burst(x + 0.5, y + 0.5, z + 0.5, DEFS[id].colors, 26, 3.6);
    this.sound.playBreak(d.sound);
    this.dropBlock(id, new THREE.Vector3(x + 0.5, y + 0.5, z + 0.5));
    this.blocksMined++;

    this.finalizeBlockRemoval(x, y, z, id, true);
    this.breakT = 0;
    this.mineCharge = 0;
    this.crack.visible = false;
    this.target = null;
  }

  private playerIntersectsBlock(x: number, y: number, z: number): boolean {
    const p = this.player.pos;
    const hw = C.PLAYER_HALF_WIDTH;
    return (
      x + 1 > p.x - hw && x < p.x + hw &&
      y + 1 > p.y && y < p.y + this.player.height &&
      z + 1 > p.z - hw && z < p.z + hw
    );
  }

  private yawCardinal(yaw: number): 'N' | 'E' | 'S' | 'W' {
    const a = ((yaw % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
    if (a < Math.PI * 0.25 || a >= Math.PI * 1.75) return 'N';
    if (a < Math.PI * 0.75) return 'W';
    if (a < Math.PI * 1.25) return 'S';
    return 'E';
  }

  private facingBlock(family: 'belt' | 'inserter' | 'miner', yaw: number): number {
    const c = this.yawCardinal(yaw);
    if (family === 'belt') {
      return c === 'N' ? B.CONVEYOR_N : c === 'E' ? B.CONVEYOR_E : c === 'S' ? B.CONVEYOR_S : B.CONVEYOR_W;
    }
    if (family === 'miner') {
      return c === 'N' ? B.LASER_MINER_N : c === 'E' ? B.LASER_MINER_E : c === 'S' ? B.LASER_MINER_S : B.LASER_MINER_W;
    }
    return c === 'N' ? B.INSERTER_N : c === 'E' ? B.INSERTER_E : c === 'S' ? B.INSERTER_S : B.INSERTER_W;
  }

  private rotateConveyor(x: number, y: number, z: number, id: number): void {
    const NEXT: Record<number, number> = {
      [B.CONVEYOR_N]: B.CONVEYOR_E,
      [B.CONVEYOR_E]: B.CONVEYOR_S,
      [B.CONVEYOR_S]: B.CONVEYOR_W,
      [B.CONVEYOR_W]: B.CONVEYOR_N,
      [B.INSERTER_N]: B.INSERTER_E,
      [B.INSERTER_E]: B.INSERTER_S,
      [B.INSERTER_S]: B.INSERTER_W,
      [B.INSERTER_W]: B.INSERTER_N,
      [B.LASER_MINER_N]: B.LASER_MINER_E,
      [B.LASER_MINER_E]: B.LASER_MINER_S,
      [B.LASER_MINER_S]: B.LASER_MINER_W,
      [B.LASER_MINER_W]: B.LASER_MINER_N,
    };
    const next = NEXT[id];
    if (next === undefined) return;
    this.world.setBlock(x, y, z, next);
    this.sound.playPlace('stone');
    this.particles.burst(x + 0.5, y + 1.02, z + 0.5, DEFS[next].colors, 6, 1.2);
    this.placeCd = 0.22;
  }

  private placeBlock(): void {
    const item = this.inventory.hotbar[this.sel];
    if (!item || item.kind !== 'block' || item.count <= 0) return;
    if (item.blockId === B_COAL || item.blockId === B_STICK) return;
    const hit = this.target;
    if (!hit || !this.mouse.right || this.placeCd > 0) return;

    const atPlant = DEFS[hit.id].cross === true;
    const x = atPlant ? hit.x : hit.x + hit.nx;
    const y = atPlant ? hit.y : hit.y + hit.ny;
    const z = atPlant ? hit.z : hit.z + hit.nz;

    const existing = this.world.getBlockRaw(x, y, z);
    if (existing === -1) return;
    const exDef = DEFS[existing];
    const replaceable = existing === B.AIR || isWaterId(existing) || (exDef.cross ?? false);
    if (!replaceable) return;

    let ourId = FROM_FPS[item.blockId] ?? B.STONE;

    if (isConveyor(ourId)) {
      if (!DEFS[this.world.getBlockRaw(x, y - 1, z)]?.solid) return;
      ourId = this.facingBlock('belt', this.player.yaw);
    }

    if (isInserter(ourId)) {
      if (!DEFS[this.world.getBlockRaw(x, y - 1, z)]?.solid) return;
      ourId = this.facingBlock('inserter', this.player.yaw);
    }

    if (isLaserMiner(ourId)) {
      if (!DEFS[this.world.getBlockRaw(x, y - 1, z)]?.solid) return;
      ourId = this.facingBlock('miner', this.player.yaw);
    }

    if (ourId === B.TURRET) {
      if (!DEFS[this.world.getBlockRaw(x, y - 1, z)]?.solid) return;
    }

    const d = DEFS[ourId];
    if (d.solid && this.playerIntersectsBlock(x, y, z)) return;
    if (ourId === B.TORCH && !atPlant) {
      const supportDef = DEFS[hit.id];
      if (!supportDef?.solid) return;
    }

    this.world.setBlock(x, y, z, ourId);
    if (ourId === B.TORCH) this.torchLights.add(x, y, z, x - hit.nx, y - hit.ny, z - hit.nz);
    this.particles.burst(x + 0.5, y + 0.5, z + 0.5, d.colors, 8, 1.7);
    this.sound.playPlace(d.sound);
    this.heldBlock.triggerPlace();
    this.inventory.consumeBlock({ isHotbar: true, index: this.sel });
    this.placeCd = 0.22;
    if (item.count - 1 <= 0) this.selectSlot(this.sel, true);
  }

  private updateFood(dt: number): void {
    const item = this.inventory.hotbar[this.sel];

    if (!item || item.kind !== 'food' || item.count <= 0 || this.dead || !this.locked) {
      this.eating = false;
      this.eatT = 0;
      this.biteAcc = 0;
      this.heldFood.visible = false;
      return;
    }

    this.heldFood.visible = true;
    const baseX = 0.38, baseY = -0.32, baseZ = -0.52;
    const baseRX = 0.35, baseRY = -0.55, baseRZ = 0.25;

    if (!this.mouse.right) {
      this.eating = false;
      this.eatT = Math.max(0, this.eatT - dt * 2);
      this.biteAcc = 0;
    } else {
      this.eating = true;
      this.eatT += dt;
      this.biteAcc += dt;
    }

    const EAT_TIME = 1.6;
    const p = Math.min(1, this.eatT / EAT_TIME);
    const riseE = this.eating ? Math.min(1, this.eatT * 4) : p;
    const chomp = this.eating ? Math.abs(Math.sin(this.eatT * Math.PI * 4)) : 0;
    const chompDir = Math.sin(this.eatT * Math.PI * 4) >= 0 ? 1 : -1;
    const amp = 0.026 + p * 0.018;

    this.heldFood.position.set(
      baseX - riseE * 0.07,
      baseY + riseE * 0.11 + chomp * amp,
      baseZ + riseE * 0.06 - chomp * 0.012,
    );
    this.heldFood.rotation.set(
      baseRX + riseE * 0.25 + chomp * 0.35,
      baseRY + riseE * 0.2,
      baseRZ + chompDir * chomp * 0.12,
    );

    if (!this.eating) return;

    if (this.biteAcc > 0.25) {
      this.biteAcc = 0;
      this.fpsAudio.foley('grab');
      this.camera.getWorldDirection(this.aimDir);
      const mouth = this.camera.position.clone()
        .addScaledVector(this.aimDir, 0.3)
        .add(new THREE.Vector3(0, -0.05, 0));
      for (let i = 0; i < 5; i++) {
        this.fx.spawnParticle(
          mouth,
          new THREE.Vector3(
            (Math.random() - 0.5) * 1.2,
            -0.4 - Math.random() * 0.6,
            (Math.random() - 0.5) * 1.2,
          ),
          0xc08050, 0.016 + Math.random() * 0.012, 0.5, true,
        );
      }
    }

    if (p >= 1) {
      this.eating = false;
      this.eatT = 0;
      this.biteAcc = 0;
      this.inventory.consumeAt({ isHotbar: true, index: this.sel });
      const food = FOODS[item.foodId];
      this.hp = Math.min(this.maxHp, this.hp + (food?.heal ?? 10));
      this.fpsAudio.ding();
      const head = this.camera.position.clone().addScaledVector(this.aimDir, 0.32);
      for (let i = 0; i < 8; i++) {
        this.fx.spawnParticle(
          head,
          new THREE.Vector3(
            (Math.random() - 0.5) * 1.6,
            -0.2 - Math.random() * 0.8,
            (Math.random() - 0.5) * 1.6,
          ),
          0xd8a86a, 0.018, 0.6, true,
        );
      }
      this.selectSlot(this.sel, true);
      this.statT = 0;
    }
  }

  private applyUnderwaterFx(): void {
    if (this.player.headInWater) {
      this.scene.background = UNDERWATER_FOG;
      FOG_UNIFORMS.uFogColor.value.copy(UNDERWATER_FOG);
      FOG_UNIFORMS.uSkyFogColor.value.copy(UNDERWATER_FOG);
      FOG_UNIFORMS.uSkyFog.value = 0.92;
      FOG_UNIFORMS.uFogDensity.value = Math.max(FOG_UNIFORMS.uFogDensity.value, 0.045);
      FOG_UNIFORMS.uFogStart.value = 1.5;
    } else {
      this.scene.background = this.sky.skyColor;
    }
  }


  private updateDamageBearing(): void {
    if (!this.hasDamageFrom) return;
    const p = this.player.pos;
    const dx = C.minImageF(this.lastDamageFrom.x - p.x);
    const dz = C.minImageF(this.lastDamageFrom.z - p.z);
    const yaw = this.player.yaw;
    const fwd = dx * -Math.sin(yaw) + dz * -Math.cos(yaw);
    const right = dx * Math.cos(yaw) + dz * -Math.sin(yaw);
    if (fwd !== 0 || right !== 0) this.dmgAngle = Math.atan2(right, fwd);
  }

  private damagePlayer(dmg: number, from: THREE.Vector3): void {
    if (this.dead || this.invulnT > 0 || !this.locked || this.piloting) return;
    this.hp = Math.max(0, this.hp - dmg);
    this.damageSeq++;
    this.lastDamageFrom.copy(from);
    this.hasDamageFrom = true;
    this.dmgFollowT = 1.2;
    this.updateDamageBearing();
    this.statT = 0;
    this.fpsAudio.hurt();
    this.player.addShake(0.012);

    if (this.hp <= 0) {
      const p = this.player.pos;
      const img = new THREE.Vector3(
        p.x + C.minImageF(from.x - p.x),
        from.y,
        p.z + C.minImageF(from.z - p.z),
      );
      this.dead = true;
      this.deadTimer = 0;
      this.weapons.startDeath();
      this.spawnDroppedWeapon();
      this.fpsAudio.playerDie();
      this.player.startDeath(img);
      this.enemies.onPlayerDeath(6);
      const head = this.camera.position.clone();
      for (let i = 0; i < 16; i++) {
        this.fx.spawnParticle(
          head,
          new THREE.Vector3(
            (Math.random() - 0.5) * 3,
            Math.random() * 2,
            (Math.random() - 0.5) * 3,
          ),
          0xd0342c, 0.03 + Math.random() * 0.03, 0.8, true,
        );
      }
    }
  }

  private respawn(): void {
    this.dead = false;
    this.deadTimer = 0;
    this.hp = this.maxHp;
    this.sky.skipToMorning();
    this.invulnT = 1.5;
    this.hasDamageFrom = false;
    this.dmgFollowT = 0;
    if (this.droppedGun) {
      this.scene.remove(this.droppedGun.mesh);
      this.droppedGun = null;
    }

    this.player.resetDeath();
    this.flow.invalidateNow();
    this.lastFieldX = NaN; this.lastFieldY = NaN; this.lastFieldZ = NaN;
    this.player.setSpawn(this.ship.pos.x, this.ship.pos.y - 0.2, this.ship.pos.z);
    this.player.yaw = this.ship.yaw;
    this.player.pitch = 0;
    this.wasOnGround = false;
    this.wasInWater = false;
    this.prevVelY = 0;
    this.spaceExited = false;
    this.weapons.resetDeath();
    this.selectSlot(this.sel, true);
    this.boardShip(true);
    this.statT = 0;
  }

  private spawnDroppedWeapon(): void {
    const gun = this.weapons.rig.gun.clone(true);
    gun.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.isMesh) { m.castShadow = true; m.frustumCulled = true; }
    });
    gun.position.copy(this.camera.position);
    gun.scale.setScalar(1);
    this.scene.add(gun);

    const fwd = new THREE.Vector3();
    this.camera.getWorldDirection(fwd);
    this.droppedGun = {
      mesh: gun,
      vel: fwd.multiplyScalar(1.5).add(
        new THREE.Vector3((Math.random() - 0.5) * 0.9, 1.1, (Math.random() - 0.5) * 0.9),
      ),
      spin: new THREE.Vector3(
        (Math.random() - 0.5) * 7,
        (Math.random() - 0.5) * 7,
        (Math.random() - 0.5) * 7,
      ),
      settled: false,
    };
  }

  private updateDroppedWeapon(dt: number) {
    const g = this.droppedGun;
    if (!g || g.settled) return;
    g.vel.y -= 22 * dt;
    g.mesh.position.addScaledVector(g.vel, dt);
    g.mesh.rotation.x += g.spin.x * dt;
    g.mesh.rotation.y += g.spin.y * dt;
    g.mesh.rotation.z += g.spin.z * dt;

    const bx = Math.floor(g.mesh.position.x);
    const by = Math.floor(g.mesh.position.y - 0.06);
    const bz = Math.floor(g.mesh.position.z);
    if (this.world.solid(bx, by, bz) && g.vel.y < 0) {
      g.mesh.position.y = by + 1.06;
      g.vel.y *= -0.28;
      g.vel.x *= 0.5; g.vel.z *= 0.5;
      g.spin.multiplyScalar(0.42);
      this.fpsAudio.foley('grab');
      if (Math.abs(g.vel.y) < 0.7) {
        g.settled = true;
        g.vel.set(0, 0, 0);
        g.spin.set(0, 0, 0);
      }
    }
  }

  private fireShot(
    muzzle: THREE.Vector3,
    dir: THREE.Vector3,
    weaponId: string,
    muzzleAnchor: THREE.Object3D,
  ): void {
    const origin = this.camera.position.clone();
    const worldHit = this.world.raycast(origin, dir, 130);
    const enemyHit = this.enemies.raycast(origin, dir, 130);
    this.enemies.alertNearby(origin, weaponId === 'sniper' ? 70 : 50);

    this.raycaster.set(origin, dir);
    this.raycaster.far = 130;
    let targetHit: { t: Target; point: THREE.Vector3; dist: number } | null = null;
    for (const t of this.targets) {
      const hits = this.raycaster.intersectObject(t.board, false);
      if (hits.length > 0 && (!targetHit || hits[0].distance < targetHit.dist)) {
        targetHit = { t, point: hits[0].point.clone(), dist: hits[0].distance };
      }
    }

    const wd = worldHit ? worldHit.dist : Infinity;
    const ed = enemyHit ? enemyHit.dist : Infinity;
    const td = targetHit ? targetHit.dist : Infinity;
    const useEnemy = !!enemyHit && ed <= wd && ed <= td;
    const useTarget = !useEnemy && !!targetHit && td <= wd;

    const end = useEnemy ? enemyHit!.point.clone()
      : useTarget ? targetHit!.point.clone()
      : worldHit ? worldHit.point.clone()
      : origin.clone().addScaledVector(dir, 130);

    this.fx.muzzleFlash(muzzle, 0.5, muzzleAnchor);
    this.fx.tracer(muzzle, end, muzzleAnchor);

    if (useEnemy) {
      const eh = enemyHit!;
      eh.enemy.takeDamage(weaponId === 'sniper' ? 50 : weaponId === 'bazooka' ? 999 : 12, eh.point, eh.headshot);
      this.enemies.alertAlliesOf(eh.enemy);
      this.hitSeq++;
      if (eh.headshot) this.fpsAudio.headshot(); else this.fpsAudio.enemyHit();
    } else if (useTarget) {
      this.hitTarget(targetHit!.t, dir);
      this.fx.puff(targetHit!.point, dir.clone().negate(), 0.25, 0.5, '#ffffff');
      this.targetsHit++;
    } else if (worldHit) {
      this.fx.impact(worldHit.point, worldHit.normal, worldHit.block, worldHit);
      if ((worldHit.block === B.STONE || worldHit.block === B.GRAVEL) && Math.random() < 0.3) {
        this.fpsAudio.ricochet();
      }
    }
  }

  private launchRocket(muzzle: THREE.Vector3, dir: THREE.Vector3, muzzleAnchor: THREE.Object3D): void {
    this.fx.muzzleFlash(muzzle, 0.7, muzzleAnchor);
    this.fx.launchRocket(muzzle.clone().addScaledVector(dir, 0.4), dir);
    this.fpsAudio.whoosh();
    this.player.addShake(0.03);
  }

  private handleExplosion(pos: THREE.Vector3): void {
    const dist = pos.distanceTo(this.player.pos);
    this.enemies.damageInRadius(pos, 3.4, 120);
    this.enemies.alertInRadius(pos, 18);

    const MAX_BLAST_DROPS = 14;
    let drops = 0;
    const destroyed = this.world.destroySphere(pos, 2.9, (x, y, z, id) => {
      this.spillMachineOnBreak(x, y, z, id);
      this.removeFloatingPlantsAbove(x, y, z);
      if (id === B.TORCH) this.torchLights.remove(x, y, z);
      this.detachTorchesSupportedBy(x, y, z, false);
      if (drops >= MAX_BLAST_DROPS || Math.random() > 0.28) return;
      drops++;
      this.dropBlock(id, new THREE.Vector3(x + 0.5, y + 0.5, z + 0.5));
    });

    if (destroyed > 0) {
      this.demolition += destroyed;
      this.enemies.notifyWorldChanged(pos, 34);
    }

    this.fpsAudio.explosion(dist);
    this.player.addShake(THREE.MathUtils.clamp(0.05 - dist * 0.0022, 0.004, 0.05));
    if (dist < 6.5) this.damagePlayer(Math.round((1 - dist / 6.5) * 42), pos);
  }


  private getBiomeName(x: number, z: number): string {
    this.biomeCheckT--;
    if (this.biomeCheckT <= 0) {
      this.biomeCheckT = 3;
      this.cachedBiomeName = this.world.gen.biomeDefAt(Math.floor(x), Math.floor(z)).name;
    }
    return this.cachedBiomeName;
  }

  private reportStats(dt: number): void {
    this.statT -= dt;
    if (this.statT > 0) return;
    this.statT = this.dmgFollowT > 0 ? 0.05 : 0.25;
    this.events.onStats(this.buildStats());
  }

  private buildStats(): HudStats {
    this.updateDamageBearing();
    const p = this.player.pos;
    const shipAlt = this.piloting && this.ship ? Math.max(0, Math.round(this.shipAltitude())) : 0;

    const selItem = this.inventory.hotbar[this.sel] ?? null;
    const weaponId =
      selItem && selItem.kind === 'weapon' ? selItem.weaponId :
      this.toolMode === 'laser' ? 'laser' :
      this.toolMode === 'barehand' ? 'barehand' : 'block';
    const weaponName =
      selItem && selItem.kind === 'weapon' ? (WEAPONS[selItem.weaponId]?.name ?? LASER_NAME) :
      selItem && selItem.kind === 'food' ? (FOODS[selItem.foodId]?.name ?? 'Food') :
      selItem && selItem.kind === 'block' ? (BLOCK_NAMES[selItem.blockId] ?? 'Block') :
      this.toolMode === 'barehand' ? 'Bare Hands' : LASER_NAME;
    const ammo =
      selItem && (selItem.kind === 'block' || selItem.kind === 'food') ? selItem.count :
      this.toolMode === 'weapon' ? this.weapons.ammoInfo.ammo : -1;
    const mag = this.toolMode === 'weapon' ? this.weapons.ammoInfo.mag : selItem && selItem.kind === 'block' ? 64 : 0;

    return {
      fps: Math.round(this.fps),
      x: Math.floor(C.wrapBlock(p.x)),
      y: Math.floor(p.y),
      z: Math.floor(C.wrapBlock(p.z)),
      biome: this.getBiomeName(p.x, p.z),
      time: this.sky.time,
      underwater: this.player.headInWater,
      muted: this.sound.muted,
      isDay: this.sky.isDay,
      piloting: this.piloting,
      shipSpeed: Math.round(this.ship ? this.ship.speed() : 0),
      shipAlt,
      shipNear: !this.piloting && !!this.ship && this.ship.distanceTo(this.player.eye()) < 6,
      hp: Math.max(0, Math.round(this.hp)),
      maxHp: this.maxHp,
      kills: this.kills,
      enemiesAlive: this.enemies.aliveCount,
      dead: this.dead,
      respawnIn: Math.max(0, Math.ceil(DEATH_DURATION - this.deadTimer)),
      toolMode: this.toolMode,
      weaponId,
      weaponName,
      ammo,
      mag,
      reloading: this.weapons.reloading,
      reloadT: this.weapons.reloadProgress,
      inventoryOpen: this.inventoryOpen,
      craftingOpen: this.craftingOpen,
      furnaceOpen: !!this.openFurnaceKey,
      furnaceBurn: (() => {
        const f = this.openFurnace;
        return f && f.burnMax > 0 ? Math.max(0, Math.min(1, f.burn / f.burnMax)) : 0;
      })(),
      furnaceCook: (() => {
        const f = this.openFurnace;
        return f ? Math.max(0, Math.min(1, f.cook / SMELT_TIME)) : 0;
      })(),
      slot: this.sel,
      enemiesEnabled: this.enemiesEnabled,
      mineCharge: this.mineCharge,
      heldBlockId:
        selItem && selItem.kind === 'block' && this.toolMode === 'block' ? selItem.blockId : null,
      scoped: this.weapons.scoped,
      ads: this.weapons.adsT,
      hitSeq: this.hitSeq,
      damageSeq: this.damageSeq,
      dmgAngle: this.dmgAngle,
      demolition: this.demolition,
      blocksMined: this.blocksMined,
      targetsHit: this.targetsHit,
      session: 1 - (this.time % 300) / 300,
      switchAt: this.switchAt,
      spread:
        7 + this.weapons.bloomPx * 26 +
        Math.min(1, this.player.speedSmooth / 6) * 9 * (1 - this.weapons.adsT * 0.9),
      coins: this.coins,
      coinSeq: this.coinSeq,
      lastCoinGain: this.lastCoinGain,
      nearMerchant: this.nearMerchant,
      shopOpen: !!this.shopEnemy,
      shopMerchantName: this.shopEnemy ? this.shopEnemy.cfg.name : null,
      shopStock: this.shopStock.map((s) => ({ ...s })),
      shopSellOpen: this.shopSellOpen,
    };
  }

  getWorld(): World {
    return this.world;
  }

  getPlayer(): Player {
    return this.player;
  }

  private capturePersistence(): void {
    if (!this.sim || !this.persistDeltas || !this.persistLedger) return;
    universeSim.release(this.worldKey);
    const p = this.player.pos;
    hub.capture({
      planetKey: this.worldKey,
      worldSeed: this.worldSeed,
      themeSea: this.themeSea,
      themeJson: this.theme ? themeToJson(this.theme) : null,
      deltas: this.persistDeltas,
      ledger: this.persistLedger,
      sim: this.sim,
      furnaces: this.furnaces,
      craftingTables: this.craftingTables,
      playerState: () => ({ x: p.x, y: p.y, z: p.z, yaw: this.player.yaw }),
    });
  }

  dispose(): void {
    this.disposed = true;
    this.renderer.setAnimationLoop(null);
    this.sound.stopShip();
    this.itemDrops?.clear();
    this.capturePersistence();
    this.machines?.dispose();
    this.inserters?.clear();
    this.laserMiners?.clear();
    this.turrets?.clear();
    this.removeListeners();
    window.removeEventListener('resize', this.resize);
    this.world?.materials.cutoutDepth?.dispose();
    this.world?.materials.foliageDepth?.dispose();
    this.lumenLite?.dispose();
    this.depthFogPass?.dispose();
    this.bloom?.dispose();
    this.volumetricLight?.dispose();
    this.outputStage?.dispose();
    this.mainRT?.dispose();
    this.lightingRT?.dispose();
    this.fogRT?.dispose();
    this.volumetricRT?.dispose();
    this.giRT?.dispose();
    this.blurRT?.dispose();
    for (const g of this.blockGeomCache.values()) g.dispose();
    this.blockGeomCache.clear();
    this.weapons?.dispose();
    this.scene.traverse((o) => {
      if (o instanceof THREE.Mesh || o instanceof THREE.LineSegments || o instanceof THREE.Points) {
        o.geometry.dispose();
        const m = o.material as THREE.Material | THREE.Material[];
        if (Array.isArray(m)) m.forEach((mm) => mm.dispose());
        else m.dispose();
      }
    });
    this.renderer.dispose();
  }
}