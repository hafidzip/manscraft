
import { useEffect, useRef, type RefObject } from 'react';
import type { GameEngine } from '../game/engine';
import { SEA_LEVEL } from '../game/core/constants';

const SIZE = 176;
const SAMPLES = 96;
const HALF = SAMPLES / 2;
const REFRESH_MS = 180;

export function Minimap({ engineRef }: { engineRef: RefObject<GameEngine | null> }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d')!;
    ctx.imageSmoothingEnabled = false;

    const img = ctx.createImageData(SAMPLES, SAMPLES);
    const heights = new Uint8Array(SAMPLES * SAMPLES);
    const colors = new Uint32Array(SAMPLES * SAMPLES);
    const water = new Uint8Array(SAMPLES * SAMPLES);

    const t = setInterval(() => {
      const engine = engineRef.current;
      const world = engine?.getWorld();
      const player = engine?.getPlayer();
      if (!engine || !world || !player) return;

      const px = Math.floor(player.pos.x);
      const pz = Math.floor(player.pos.z);
      const d = img.data;

      world.sampleMapRegion(px - HALF, pz - HALF, SAMPLES, heights, colors, water);

      for (let s = 0; s < heights.length; s++) {
        const i = s * 4;
        const height = heights[s];
        d[i + 3] = 255;
        if (height <= 0) {
          d[i] = 13;
          d[i + 1] = 19;
          d[i + 2] = 28;
          continue;
        }
        const color = colors[s];
        let r = (color >> 16) & 255;
        let g = (color >> 8) & 255;
        let b = color & 255;
        const f = 0.6 + 0.5 * Math.min(1, Math.max(0, (height - 12) / 46));
        r *= f;
        g *= f;
        b *= f;
        if (water[s]) {
          const deep = Math.min(1, Math.max(0, (SEA_LEVEL - height) / 12));
          r = r * (1 - deep) + 18 * deep;
          g = g * (1 - deep) + 40 * deep;
          b = Math.min(255, b * (1 - deep * 0.5) + 90 * deep);
        }
        d[i] = r;
        d[i + 1] = g;
        d[i + 2] = b;
      }

      ctx.clearRect(0, 0, SIZE, SIZE);
      ctx.save();
      ctx.beginPath();
      ctx.arc(SIZE / 2, SIZE / 2, SIZE / 2 - 2, 0, Math.PI * 2);
      ctx.clip();
      ctx.putImageData(img, 0, 0);
      ctx.drawImage(canvas, 0, 0, SAMPLES, SAMPLES, 0, 0, SIZE, SIZE);

      const yaw = player.yaw;
      const fx = -Math.sin(yaw);
      const fz = -Math.cos(yaw);
      const rot = Math.atan2(fx, -fz);
      ctx.translate(SIZE / 2, SIZE / 2);
      ctx.rotate(rot);
      ctx.beginPath();
      ctx.moveTo(0, -7);
      ctx.lineTo(5, 6);
      ctx.lineTo(0, 3);
      ctx.lineTo(-5, 6);
      ctx.closePath();
      ctx.fillStyle = '#ffffff';
      ctx.strokeStyle = 'rgba(0,0,0,0.7)';
      ctx.lineWidth = 2;
      ctx.fill();
      ctx.stroke();
      ctx.restore();

      ctx.save();
      ctx.font = '10px VT323, monospace';
      ctx.textAlign = 'center';
      ctx.fillStyle = 'rgba(255,255,255,0.85)';
      ctx.shadowColor = 'rgba(0,0,0,0.8)';
      ctx.shadowBlur = 2;
      ctx.fillText('N', SIZE / 2, 13);
      ctx.restore();
    }, REFRESH_MS);

    return () => clearInterval(t);
  }, [engineRef]);

  return (
    <div className="pointer-events-none absolute right-4 top-4 z-20 flex flex-col items-center gap-1.5">
      <canvas
        ref={canvasRef}
        width={SIZE}
        height={SIZE}
        className="rounded-full border-2 border-black/60 shadow-[0_0_0_2px_rgba(255,255,255,0.25),0_4px_16px_rgba(0,0,0,0.5)]"
      />
    </div>
  );
}
